import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { getDb } from './server/db.ts';
import { createApiRouter } from './server/routes/api.ts';

async function startServer(): Promise<void> {
  const port = Number(process.env.PORT || 3000);

  // Initialize local SQLite database
  getDb();

  const app = express();
  app.use(express.json({ limit: '6mb' }));

  // Mount Project Genesis modular API
  app.use('/api', createApiRouter());

  if (process.env.NODE_ENV === 'production') {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      const indexFile = path.join(distDir, 'index.html');
      if (fs.existsSync(indexFile)) {
        res.sendFile(indexFile);
      } else {
        res.status(404).send('Build output not found. Run npm run build first.');
      }
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const host = process.env.HOST || (process.env.K_SERVICE ? '0.0.0.0' : '127.0.0.1');

  app.listen(port, host, () => {
    console.log(`[Project Genesis] Core Platform listening on http://${host}:${port}`);
  });
}

startServer().catch((err) => {
  console.error('[Project Genesis] Failed to start server:', err);
  process.exit(1);
});
