# Project Genesis — System Architecture (Step 01)

## 1. Architectural Overview

Project Genesis separates presentation, orchestration, persistence, and neural inference into distinct layers so future foundation models can be swapped in without modifying UI components or database schemas.

```text
+-------------------------------------------------------------------+
|  Frontend Workstation (React + TypeScript + Tailwind CSS)         |
|  10 Independent Modules · src/components/modules/                 |
+-------------------------------------------------------------------+
                                |
                    REST / JSON over /api/*
                                |
+-------------------------------------------------------------------+
|  Backend API Layer                                                |
|  - Python FastAPI Scaffold (/backend/app/api/routes/)             |
|  - Node.js Express Runtime (/server/routes/api.ts)                |
+-------------------------------------------------------------------+
          |                                           |
+---------------------------+     +---------------------------------+
|  Local SQLite Database    |     |  Provider-Independent AI Layer  |
|  ./data/genesis.db        |     |  - BaseModelAdapter             |
|  - conversations          |     |  - BaseInferenceEngine          |
|  - messages               |     |  - BaseTokenizer                |
|  - memory_entries         |     |  - BaseMemoryStore              |
|  - research_projects      |     |  - BaseAgentOrchestrator        |
|  - models                 |     |  - BaseToolExecutor             |
|  - agents                 |     |  - ModelConfigManager           |
|  - laboratory_items       |     +---------------------------------+
|  - creator_artifacts      |                     |
|  - system_settings        |     +---------------------------------+
+---------------------------+     |  Adapters (Step 01 / Future)    |
                                  |  - GenesisCorePlaceholderAdapter|
                                  |  - LocalHttpInferenceAdapter    |
                                  +---------------------------------+
```

## 2. Independent AI Layer

Located in `backend/app/ai/` (Python) and `src/ai/contracts.ts` (TypeScript):

1. **Model Interface (`BaseModelAdapter`)**: Manages weight loading (`load_weights`), unloading (`unload_weights`), and model capability declarations.
2. **Inference Interface (`BaseInferenceEngine`)**: Executes `generate(InferenceRequest) -> InferenceResponse`.
3. **Tokenizer Interface (`BaseTokenizer`)**: Step 01 ships a deterministic baseline tokenizer (`BaselineTokenizer`) for real UTF-8 byte accounting and context budgeting; Step 02 will replace or extend this with a trained BPE/SentencePiece vocabulary.
4. **Memory Interface (`BaseMemoryStore`)**: Namespace-scoped structured storage backed by SQLite.
5. **Agent Orchestration Interface (`BaseAgentOrchestrator`)**: Step-budgeted planner that pauses cleanly at reasoning steps when no foundation model is loaded.
6. **Tool Execution Interface (`BaseToolExecutor`)**: Allowlist-only validator (`health_check`, `inspect_tokenizer`, `validate_json_schema`, `list_models`).
7. **Model Configuration Manager (`ModelConfigManager`)**: Tracks local weight paths, quantization metadata, context limits, and local inference endpoints.

## 3. Security Architecture

- **No Hardcoded Secrets or External AI Keys**: All external AI SDKs are excluded.
- **Local Loopback Endpoint Enforcement**: `is_local_inference_url_safe` restricts inference HTTP calls to `127.0.0.1`, `localhost`, or `::1` to prevent SSRF.
- **Upload Validation**: Filenames are sanitized via basename stripping + character allowlisting, checked against configurable extension allowlists, and capped at `max_upload_mb`.
- **Local Authentication**: Optional operator session lock hashes passcodes with `PBKDF2-HMAC-SHA256` (100,000 iterations, random 16-byte salt) and constant-time comparison.
- **Sandboxed Tool Policy**: Agents default to `allow_network: false`, `allow_filesystem_write: false`, `allow_shell_execution: false`.
