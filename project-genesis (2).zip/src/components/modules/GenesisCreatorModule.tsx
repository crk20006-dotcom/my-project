import React, { useEffect, useState } from 'react';
import { Check, Copy, Download, Eye, Pencil, Plus, Save, Trash2 } from 'lucide-react';
import { apiClient } from '../../services/apiClient';
import type { CreatorArtifact } from '../../types/genesis';
import { MarkdownRenderer } from '../common/MarkdownRenderer';

export const GenesisCreatorModule: React.FC = () => {
  const [artifacts, setArtifacts] = useState<CreatorArtifact[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [mode, setMode] = useState<'edit' | 'preview'>('edit');
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [title, setTitle] = useState('');
  const [artifactType, setArtifactType] = useState<'markdown' | 'code' | 'json' | 'blueprint'>('markdown');
  const [language, setLanguage] = useState('markdown');
  const [content, setContent] = useState('');

  const selectArtifact = (art: CreatorArtifact) => {
    setSelectedId(art.id);
    setTitle(art.title);
    setArtifactType(art.artifact_type);
    setLanguage(art.language);
    setContent(art.content);
  };

  useEffect(() => {
    apiClient
      .listCreator()
      .then((list) => {
        setArtifacts(list);
        if (list.length > 0) selectArtifact(list[0]);
      })
      .catch((err) => setError(err instanceof Error ? err.message : 'Failed to load artifacts.'));
  }, []);

  const handleCreate = async () => {
    setError(null);
    try {
      const created = await apiClient.createArtifact({
        title: 'Untitled Blueprint',
        artifact_type: 'markdown',
        language: 'markdown',
        content: '# New Genesis Blueprint\n\nDefine architecture specifications or structured code artifacts here.',
      });
      setArtifacts((prev) => [created, ...prev]);
      selectArtifact(created);
      setMode('edit');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to create artifact.');
    }
  };

  const handleSave = async () => {
    if (!selectedId) return;
    setSaving(true);
    setError(null);
    try {
      const updated = await apiClient.updateArtifact(selectedId, {
        title,
        artifact_type: artifactType,
        language,
        content,
      });
      setArtifacts((prev) => prev.map((a) => (a.id === selectedId ? updated : a)));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to save artifact.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await apiClient.deleteArtifact(id);
      const remaining = artifacts.filter((a) => a.id !== id);
      setArtifacts(remaining);
      if (selectedId === id) {
        if (remaining[0]) selectArtifact(remaining[0]);
        else setSelectedId(null);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to delete artifact.');
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      setCopied(false);
    }
  };

  const handleDownload = () => {
    const extMap: Record<string, string> = {
      python: 'py',
      typescript: 'ts',
      json: 'json',
      markdown: 'md',
    };
    const ext = extMap[language] || 'txt';
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${title.toLowerCase().replace(/[^a-z0-9]+/g, '_') || 'artifact'}.${ext}`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const activeArtifact = artifacts.find((a) => a.id === selectedId) || null;

  return (
    <div className="h-full overflow-y-auto px-4 lg:px-8 py-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-white/[0.08]">
          <div>
            <h2 className="font-display text-xl font-semibold text-slate-100">
              Genesis Creator — Artifact & Blueprint Studio
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Author, version, preview, and export technical specifications, Python adapters, and JSON schemas locally.
            </p>
          </div>
          <button
            type="button"
            onClick={() => void handleCreate()}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-medium text-white cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>New Artifact</span>
          </button>
        </div>

        {error && (
          <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/25 text-xs text-red-300">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Artifact List */}
          <div className="lg:col-span-4 space-y-2">
            {artifacts.map((art) => (
              <div
                key={art.id}
                className={`p-4 rounded-xl border transition-colors ${
                  art.id === selectedId
                    ? 'bg-[#141B26] border-blue-500/50'
                    : 'bg-[#11161F] border-white/[0.08]'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <button
                    type="button"
                    onClick={() => selectArtifact(art)}
                    className="text-left flex-1 min-w-0 cursor-pointer"
                  >
                    <div className="font-display text-sm font-semibold text-slate-100 truncate">
                      {art.title}
                    </div>
                    <div className="text-[11px] text-slate-500 mt-1 tabular-nums">
                      {art.artifact_type} · {art.language} · v{art.version}
                    </div>
                  </button>
                  <button
                    type="button"
                    onClick={() => void handleDelete(art.id)}
                    aria-label={`Delete ${art.title}`}
                    className="p-1.5 rounded text-slate-500 hover:text-red-400 hover:bg-red-500/10 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Studio Workspace */}
          <div className="lg:col-span-8">
            {activeArtifact ? (
              <div className="rounded-xl border border-white/[0.08] bg-[#11161F] p-6 space-y-4">
                <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-white/[0.08]">
                  <div className="flex items-center gap-1 p-1 rounded-lg bg-[#0A0D12] border border-white/[0.08]">
                    <button
                      type="button"
                      onClick={() => setMode('edit')}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
                        mode === 'edit' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-100'
                      }`}
                    >
                      <Pencil className="w-3.5 h-3.5" />
                      <span>Editor</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => setMode('preview')}
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium cursor-pointer ${
                        mode === 'preview' ? 'bg-blue-600 text-white' : 'text-slate-400 hover:text-slate-100'
                      }`}
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>Preview</span>
                    </button>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => void handleCopy()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/[0.1] bg-[#161C26] hover:bg-[#1E2634] text-xs text-slate-200 cursor-pointer"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copied ? 'Copied' : 'Copy'}</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleDownload}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-white/[0.1] bg-[#161C26] hover:bg-[#1E2634] text-xs text-slate-200 cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Export</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => void handleSave()}
                      disabled={saving}
                      className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-medium text-white cursor-pointer"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{saving ? 'Saving...' : 'Save Version'}</span>
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <label className="block text-xs text-slate-400 mb-1">Artifact Title</label>
                    <input
                      type="text"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      className="w-full px-3 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 focus:outline-none focus:border-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-slate-400 mb-1">Format / Language</label>
                    <select
                      value={language}
                      onChange={(e) => {
                        setLanguage(e.target.value);
                        setArtifactType(e.target.value === 'markdown' ? 'markdown' : e.target.value === 'json' ? 'json' : 'code');
                      }}
                      className="w-full px-3 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 focus:outline-none"
                    >
                      <option value="markdown">Markdown</option>
                      <option value="python">Python</option>
                      <option value="typescript">TypeScript</option>
                      <option value="json">JSON</option>
                    </select>
                  </div>
                </div>

                {mode === 'edit' ? (
                  <textarea
                    rows={14}
                    value={content}
                    onChange={(e) => setContent(e.target.value)}
                    className="w-full px-4 py-3 rounded-lg bg-[#0A0D12] border border-white/[0.1] font-mono text-[13px] leading-relaxed text-slate-100 focus:outline-none focus:border-blue-500"
                  />
                ) : (
                  <div className="p-4 rounded-lg bg-[#0A0D12] border border-white/[0.08] min-h-[300px]">
                    {language === 'markdown' ? (
                      <MarkdownRenderer content={content} />
                    ) : (
                      <MarkdownRenderer content={`\`\`\`${language}\n${content}\n\`\`\``} />
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="p-8 rounded-xl border border-white/[0.08] bg-[#11161F] text-center text-sm text-slate-400">
                Select or create an artifact to begin.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
