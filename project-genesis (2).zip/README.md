# Project Genesis — Step 01: Core Software Platform

**Project Genesis** is an independent, provider-agnostic AI Operating System software foundation. Step 01 establishes the complete frontend workstation, modular backend architecture, local SQLite persistence, security boundaries, and abstract AI engine interfaces—without relying on any external proprietary AI APIs (OpenAI, Gemini, Claude) or requiring API keys.

## Key Principles

- **Zero External AI Dependencies**: No external LLM APIs are connected. Until your own foundation model (`GENESIS CORE`) or a local inference server is connected, **Genesis Chat** operates transparently in **Demo Mode**.
- **Provider-Independent AI Contracts**: Clean interfaces (`ModelInterface`, `InferenceInterface`, `TokenizerInterface`, `MemoryInterface`, `AgentOrchestrationInterface`, `ToolExecutionInterface`, `ModelConfigurationManager`) decouple the UI and database from future neural weights.
- **Local Persistent Database**: Conversations, messages, memory namespaces, research studies, model manifests, agent blueprints, laboratory templates, creator artifacts, and security settings persist locally in SQLite (`./data/genesis.db`).
- **Dual Runtime Support**:
  - **Live Preview / Full-Stack Node Runtime**: `server.ts` serves the React SPA and `/api/*` backed by Node's built-in `node:sqlite`.
  - **Separate Python FastAPI Backend (`/backend`)**: Complete modular FastAPI project scaffold designed for independent Windows local development.

## Application Modules

1. **Genesis Chat** — Multi-thread conversation workspace with Demo Mode diagnostics, Markdown & code formatting, copy actions, and validated file attachments.
2. **Genesis Intelligence** — Interactive explorer for the 7 provider-independent AI interface contracts and live adapter endpoint verification.
3. **Genesis Agent** — Sandboxed agent blueprint builder with strict tool allowlists and deterministic dry-run execution traces.
4. **Genesis Research** — Research study manager with status filters, persistent notes, and citation tracking.
5. **Genesis Laboratory** — Deterministic baseline tokenizer inspector, context budget calculator, and JSON schema validator.
6. **Genesis Creator** — Versioned Markdown, Python, TypeScript, and JSON artifact studio with live preview and file export.
7. **Genesis Memory** — Namespace-organized persistent memory store (`semantic`, `episodic`, `procedural`, `project`) with search and JSON snapshot export.
8. **Genesis Voice** — Web Audio API live microphone waveform monitor, local audio file inspector, and STT/TTS adapter configuration.
9. **Genesis Model Manager** — Hardware telemetry, local model weight manifest registry, `GENESIS CORE` placeholder adapter, and local HTTP endpoint probing.
10. **Genesis System Settings** — Local operator passcode lock (`PBKDF2-HMAC-SHA256`), upload validation policy, health diagnostics, and full database backup/reset.

## Quick Start

### Option A: Single-Command Full-Stack Preview (Node.js 22+)
```bash
cp .env.example .env
npm install
npm run dev
```
Open `http://localhost:3000`.

### Option B: Separate Frontend + Python FastAPI Backend (Windows Development)
See [docs/DEVELOPMENT_WINDOWS.md](./docs/DEVELOPMENT_WINDOWS.md) for complete step-by-step Windows setup, testing, and future local inference engine connection instructions.

## Documentation

- [Architecture Documentation](./docs/ARCHITECTURE.md)
- [REST API Reference](./docs/API.md)
- [Windows Local Development Guide](./docs/DEVELOPMENT_WINDOWS.md)
