# Project Genesis — REST API Documentation

Base prefix: `/api`

## Health & Diagnostics

- `GET /api/health` — Returns service status, SQLite connectivity, host CPU/memory telemetry, and inference mode (`demo`).

## Conversations & Chat

- `GET /api/conversations` — List all conversations ordered by `updated_at DESC`.
- `POST /api/conversations` — Create a new conversation (`{ title, module, model_id }`).
- `PATCH /api/conversations/{id}` — Rename a conversation (`{ title }`).
- `DELETE /api/conversations/{id}` — Delete a conversation and cascade delete its messages.
- `GET /api/conversations/{id}/messages` — List all messages in chronological order.
- `POST /api/conversations/{id}/messages` — Persist user message & validated attachments, then dispatch to `LocalHttpInferenceAdapter` (if enabled) or `GenesisCorePlaceholderAdapter` (Demo Mode).
- `POST /api/upload/validate` — Validate attachment filename, extension allowlist, and size limit.

## Models & Adapters

- `GET /api/models` — List registered model manifests.
- `POST /api/models` — Register a local model manifest (`.gguf`, `.safetensors`, `local_http`, or `genesis_core`).
- `POST /api/models/{id}/probe` — Verify placeholder adapter status or probe a local loopback `/health` endpoint.
- `DELETE /api/models/{id}` — Remove a custom registered model manifest.

## Memory Store

- `GET /api/memory?namespace=&q=` — Query persistent memory entries by namespace and search text.
- `POST /api/memory` — Create a memory entry (`namespace`, `title`, `content`, `tags`, `importance`).
- `DELETE /api/memory/{id}` — Delete a memory entry.

## Agents, Research, Laboratory & Creator

- `GET /api/agents` · `POST /api/agents` · `POST /api/agents/{id}/dry-run` · `DELETE /api/agents/{id}`
- `GET /api/research` · `POST /api/research` · `PUT /api/research/{id}` · `DELETE /api/research/{id}`
- `GET /api/laboratory` · `POST /api/laboratory` · `POST /api/laboratory/tokenize` · `DELETE /api/laboratory/{id}`
- `GET /api/creator` · `POST /api/creator` · `PUT /api/creator/{id}` · `DELETE /api/creator/{id}`

## System Settings & Security

- `GET /api/settings` — Retrieve sanitized system settings (`passcode_hash` never returned).
- `PUT /api/settings` — Update security policy, upload limits, inference endpoint, and passcode.
- `POST /api/settings/verify-passcode` — Verify local operator passcode.
- `GET /api/settings/export-db` — Export full SQLite workspace snapshot as JSON.
- `POST /api/settings/reset` — Reset workspace data to Step 01 starter defaults.
