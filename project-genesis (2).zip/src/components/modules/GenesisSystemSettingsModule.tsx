import React, { useEffect, useState } from 'react';
import { Activity, Download, RotateCcw, Save, ShieldCheck } from 'lucide-react';
import { apiClient } from '../../services/apiClient';
import type { HealthResponse, ModelEntry, SystemSettings } from '../../types/genesis';

interface GenesisSystemSettingsModuleProps {
  settings: SystemSettings | null;
  onSettingsUpdated: (next: SystemSettings) => void;
}

export const GenesisSystemSettingsModule: React.FC<GenesisSystemSettingsModuleProps> = ({
  settings,
  onSettingsUpdated,
}) => {
  const [operatorName, setOperatorName] = useState(settings?.operator_name ?? 'Local Operator');
  const [localAuthEnabled, setLocalAuthEnabled] = useState(settings?.local_auth_enabled ?? false);
  const [currentPasscode, setCurrentPasscode] = useState('');
  const [newPasscode, setNewPasscode] = useState('');
  const [inferenceUrl, setInferenceUrl] = useState(
    settings?.inference_endpoint_url ?? 'http://127.0.0.1:8080'
  );
  const [preferLocal, setPreferLocal] = useState(settings?.prefer_local_inference ?? false);
  const [activeModelId, setActiveModelId] = useState(
    settings?.active_model_id ?? 'genesis-core-placeholder'
  );
  const [chatUseMemory, setChatUseMemory] = useState(settings?.chat_use_memory ?? true);
  const [chatUseKnowledge, setChatUseKnowledge] = useState(settings?.chat_use_knowledge ?? true);
  const [inferenceTemperature, setInferenceTemperature] = useState(
    settings?.inference_temperature ?? 0.2
  );
  const [inferenceMaxTokens, setInferenceMaxTokens] = useState(
    settings?.inference_max_tokens ?? 512
  );
  const [inferenceTimeoutSec, setInferenceTimeoutSec] = useState(
    Math.round((settings?.inference_timeout_ms ?? 30000) / 1000)
  );
  const [maxUploadMb, setMaxUploadMb] = useState(settings?.max_upload_mb ?? 5);
  const [allowedExtText, setAllowedExtText] = useState(
    (settings?.allowed_extensions ?? []).join(', ')
  );
  const [sandboxStrict, setSandboxStrict] = useState(settings?.sandbox_strict_mode ?? true);
  const [models, setModels] = useState<ModelEntry[]>([]);

  useEffect(() => {
    if (!settings) return;
    setOperatorName(settings.operator_name);
    setLocalAuthEnabled(settings.local_auth_enabled);
    setInferenceUrl(settings.inference_endpoint_url);
    setPreferLocal(settings.prefer_local_inference);
    setActiveModelId(settings.active_model_id ?? 'genesis-core-placeholder');
    setChatUseMemory(settings.chat_use_memory ?? true);
    setChatUseKnowledge(settings.chat_use_knowledge ?? true);
    setInferenceTemperature(settings.inference_temperature ?? 0.2);
    setInferenceMaxTokens(settings.inference_max_tokens ?? 512);
    setInferenceTimeoutSec(Math.round((settings.inference_timeout_ms ?? 30000) / 1000));
    setMaxUploadMb(settings.max_upload_mb);
    setAllowedExtText((settings.allowed_extensions ?? []).join(', '));
    setSandboxStrict(settings.sandbox_strict_mode);
  }, [settings]);

  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [saving, setSaving] = useState(false);
  const [confirmReset, setConfirmReset] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const checkHealth = async () => {
    try {
      const res = await apiClient.getHealth();
      setHealth(res);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Health check failed.');
    }
  };

  useEffect(() => {
    void checkHealth();
    apiClient
      .listModels()
      .then(setModels)
      .catch(() => {});
  }, []);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setStatusMessage(null);
    try {
      const exts = allowedExtText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);
      const updated = await apiClient.updateSettings({
        operator_name: operatorName,
        local_auth_enabled: localAuthEnabled,
        current_passcode: currentPasscode || undefined,
        new_passcode: newPasscode.trim() || undefined,
        inference_endpoint_url: inferenceUrl,
        prefer_local_inference: preferLocal,
        active_model_id: activeModelId,
        chat_use_memory: chatUseMemory,
        chat_use_knowledge: chatUseKnowledge,
        inference_temperature: inferenceTemperature,
        inference_max_tokens: inferenceMaxTokens,
        inference_timeout_ms: Math.max(1000, inferenceTimeoutSec * 1000),
        max_upload_mb: maxUploadMb,
        allowed_extensions: exts,
        sandbox_strict_mode: sandboxStrict,
      });
      onSettingsUpdated(updated);
      setCurrentPasscode('');
      setNewPasscode('');
      setStatusMessage('System security and runtime configuration saved.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to update settings.');
    } finally {
      setSaving(false);
    }
  };

  const handleExportDb = async () => {
    try {
      const snapshot = await apiClient.exportDatabaseSnapshot();
      const blob = new Blob([JSON.stringify(snapshot, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `genesis_db_backup_${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to export database.');
    }
  };

  const handleResetWorkspace = async () => {
    try {
      await apiClient.resetWorkspace();
      setConfirmReset(false);
      setStatusMessage('Workspace records reset to Step 01 defaults.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to reset workspace.');
    }
  };

  return (
    <div className="h-full overflow-y-auto px-4 lg:px-8 py-6">
      <div className="max-w-5xl mx-auto space-y-6">
        <div className="pb-5 border-b border-white/[0.08]">
          <h2 className="font-display text-xl font-semibold text-slate-100">
            Genesis System Settings & Security
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            Configure local operator authentication, file upload validation policies, inference endpoint security, and database backups.
          </p>
        </div>

        {error && (
          <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/25 text-xs text-red-300">
            {error}
          </div>
        )}
        {statusMessage && (
          <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/25 text-xs text-emerald-300">
            {statusMessage}
          </div>
        )}

        <form onSubmit={handleSave} className="space-y-6">
          {/* Security & Local Authentication */}
          <div className="rounded-xl border border-white/[0.08] bg-[#11161F] p-6 space-y-4">
            <div className="flex items-center gap-2 font-display text-base font-semibold text-slate-100">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span>Local Authentication & Operator Identity</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Operator Display Name</label>
                <input
                  type="text"
                  value={operatorName}
                  onChange={(e) => setOperatorName(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">
                  {settings?.has_passcode ? 'Update Local Passcode (optional, min 6 chars)' : 'Set Local Passcode (min 6 chars)'}
                </label>
                <input
                  type="password"
                  value={newPasscode}
                  onChange={(e) => setNewPasscode(e.target.value)}
                  placeholder={settings?.has_passcode ? 'Leave blank to keep existing' : 'Enter passcode'}
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            {settings?.has_passcode &&
              (Boolean(newPasscode.trim()) ||
                (Boolean(settings.local_auth_enabled) && !localAuthEnabled)) && (
                <div>
                  <label className="block text-xs text-slate-400 mb-1.5">
                    Current Local Passcode (required to change passcode or disable lock)
                  </label>
                  <input
                    type="password"
                    value={currentPasscode}
                    onChange={(e) => setCurrentPasscode(e.target.value)}
                    placeholder="Enter current passcode to authorize security change"
                    className="w-full sm:w-1/2 px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 focus:outline-none focus:border-blue-500"
                  />
                </div>
              )}

            <label className="flex items-center gap-2.5 text-sm text-slate-300 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={localAuthEnabled}
                onChange={(e) => setLocalAuthEnabled(e.target.checked)}
                className="accent-blue-500"
              />
              <span>Require local operator passcode lock (PBKDF2-HMAC-SHA256 verified)</span>
            </label>
          </div>

          {/* Local Inference & Upload Policy */}
          <div className="rounded-xl border border-white/[0.08] bg-[#11161F] p-6 space-y-4">
            <h3 className="font-display text-base font-semibold text-slate-100">
              Local Inference & Upload Validation Policy
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">
                  Active Chat Model Adapter
                </label>
                <select
                  value={activeModelId}
                  onChange={(e) => setActiveModelId(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 focus:outline-none focus:border-blue-500"
                >
                  {models.length === 0 ? (
                    <option value="genesis-core-placeholder">GENESIS CORE (Placeholder Adapter)</option>
                  ) : (
                    models.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name} ({m.status})
                      </option>
                    ))
                  )}
                </select>
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">
                  Local Inference Server URL (Loopback Only)
                </label>
                <input
                  type="text"
                  value={inferenceUrl}
                  onChange={(e) => setInferenceUrl(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] font-mono text-xs text-slate-100 focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Temperature (0 - 2)</label>
                <input
                  type="number"
                  min={0}
                  max={2}
                  step={0.05}
                  value={inferenceTemperature}
                  onChange={(e) => setInferenceTemperature(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 tabular-nums focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Max Output Tokens</label>
                <input
                  type="number"
                  min={32}
                  max={8192}
                  step={32}
                  value={inferenceMaxTokens}
                  onChange={(e) => setInferenceMaxTokens(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 tabular-nums focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Timeout (seconds)</label>
                <input
                  type="number"
                  min={1}
                  max={120}
                  value={inferenceTimeoutSec}
                  onChange={(e) => setInferenceTimeoutSec(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 tabular-nums focus:outline-none focus:border-blue-500"
                />
              </div>
              <div>
                <label className="block text-xs text-slate-400 mb-1.5">Max Attachment (MB)</label>
                <input
                  type="number"
                  min={1}
                  max={25}
                  value={maxUploadMb}
                  onChange={(e) => setMaxUploadMb(Number(e.target.value))}
                  className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 tabular-nums focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Allowed Attachment Extensions</label>
              <input
                type="text"
                value={allowedExtText}
                onChange={(e) => setAllowedExtText(e.target.value)}
                className="w-full px-3.5 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] font-mono text-xs text-slate-100 focus:outline-none focus:border-blue-500"
              />
            </div>

            <div className="space-y-2 pt-1">
              <label className="flex items-center gap-2.5 text-sm text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferLocal}
                  onChange={(e) => setPreferLocal(e.target.checked)}
                  className="accent-blue-500"
                />
                <span>Dispatch Genesis Chat prompts to configured local inference endpoint</span>
              </label>

              <label className="flex items-center gap-2.5 text-sm text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={chatUseMemory}
                  onChange={(e) => setChatUseMemory(e.target.checked)}
                  className="accent-blue-500"
                />
                <span>Attach relevant approved User Memory excerpts to Genesis Chat prompts</span>
              </label>

              <label className="flex items-center gap-2.5 text-sm text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={chatUseKnowledge}
                  onChange={(e) => setChatUseKnowledge(e.target.checked)}
                  className="accent-blue-500"
                />
                <span>Attach matching Knowledge Base chunks to Genesis Chat prompts</span>
              </label>

              <label className="flex items-center gap-2.5 text-sm text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={sandboxStrict}
                  onChange={(e) => setSandboxStrict(e.target.checked)}
                  className="accent-blue-500"
                />
                <span>Enforce strict read-only sandbox for autonomous agent tools</span>
              </label>
            </div>

            <div className="flex justify-end pt-2">
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-medium text-white cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{saving ? 'Saving...' : 'Save System Configuration'}</span>
              </button>
            </div>
          </div>
        </form>

        {/* Backend Health & Data Operations */}
        <div className="rounded-xl border border-white/[0.08] bg-[#11161F] p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2 font-display text-base font-semibold text-slate-100">
              <Activity className="w-4 h-4 text-blue-400" />
              <span>Service Health & Database Storage</span>
            </div>
            <button
              type="button"
              onClick={() => void checkHealth()}
              className="px-3 py-1.5 rounded-lg border border-white/[0.1] bg-[#161C26] hover:bg-[#1E2634] text-xs font-medium text-slate-200 cursor-pointer"
            >
              Run Health Check
            </button>
          </div>

          {health && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div className="p-3.5 rounded-lg bg-[#0A0D12] border border-white/[0.07]">
                <div className="text-slate-500">API Status</div>
                <div className="font-semibold text-emerald-400 mt-1 uppercase">{health.status}</div>
                <div className="text-slate-500 mt-0.5 truncate">{health.runtime}</div>
              </div>
              <div className="p-3.5 rounded-lg bg-[#0A0D12] border border-white/[0.07]">
                <div className="text-slate-500">Persistent Database</div>
                <div className="font-semibold text-slate-200 mt-1">{health.database.engine}</div>
                <div className="font-mono text-[11px] text-slate-500 mt-0.5 truncate">{health.database.path}</div>
              </div>
              <div className="p-3.5 rounded-lg bg-[#0A0D12] border border-white/[0.07]">
                <div className="text-slate-500">External AI APIs</div>
                <div className="font-semibold text-slate-200 mt-1">
                  {health.model_inference.external_ai_apis_disabled ? 'Disabled' : 'Enabled'}
                </div>
                <div className="text-slate-500 mt-0.5">Independent local operation</div>
              </div>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/[0.08]">
            <button
              type="button"
              onClick={() => void handleExportDb()}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-white/[0.1] bg-[#161C26] hover:bg-[#1E2634] text-xs font-medium text-slate-200 cursor-pointer"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export Full SQLite JSON Backup</span>
            </button>

            {confirmReset ? (
              <div className="flex items-center gap-2">
                <span className="text-xs text-red-300">Confirm reset of workspace records?</span>
                <button
                  type="button"
                  onClick={() => void handleResetWorkspace()}
                  className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-500 text-xs font-medium text-white cursor-pointer"
                >
                  Confirm Reset
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmReset(false)}
                  className="px-3 py-1.5 rounded-lg border border-white/[0.1] text-xs text-slate-300 cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => setConfirmReset(true)}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-red-500/30 bg-red-500/10 hover:bg-red-500/20 text-xs font-medium text-red-300 cursor-pointer"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Demo Workspace</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
