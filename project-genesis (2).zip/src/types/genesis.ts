export type ModuleId =
  | 'chat'
  | 'intelligence'
  | 'agent'
  | 'research'
  | 'laboratory'
  | 'creator'
  | 'memory'
  | 'voice'
  | 'models'
  | 'settings';

export interface AttachmentMeta {
  id: string;
  name: string;
  size: number;
  mimeType: string;
  extension: string;
  previewText?: string;
  validated: boolean;
}

export interface MemoryRetrievalSummary {
  queried: boolean;
  retrieval_backend: string;
  memories_used: Array<{ id: string; title: string; category: string }>;
  knowledge_used: Array<{ document_id: string; document_title: string; chunk_index: number }>;
  total_context_tokens: number;
}

export interface Message {
  id: string;
  conversation_id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  attachments: AttachmentMeta[];
  metadata: {
    mode: 'demo' | 'local_inference' | 'genesis_core';
    model_id?: string;
    model_name?: string;
    token_count?: number;
    prompt_tokens?: number;
    completion_tokens?: number;
    finish_reason?: string;
    truncated_messages?: number;
    partial?: boolean;
    diagnostic?: boolean;
    memory_retrieval?: MemoryRetrievalSummary;
  };
  created_at: string;
}

export interface Conversation {
  id: string;
  title: string;
  module: string;
  model_id: string | null;
  created_at: string;
  updated_at: string;
  message_count?: number;
}

export type MemoryNamespace = 'episodic' | 'semantic' | 'procedural' | 'project';
export type MemoryCategory = 'fact' | 'preference' | 'instruction' | 'constraint';

export interface MemoryEntry {
  id: string;
  namespace: MemoryNamespace;
  category?: MemoryCategory;
  title: string;
  content: string;
  tags: string[];
  importance: number;
  approved?: boolean;
  source_conversation_id?: string | null;
  created_at: string;
  updated_at: string;
}

export interface KnowledgeChunk {
  id: string;
  document_id: string;
  chunk_index: number;
  content: string;
  token_estimate: number;
  created_at: string;
}

export interface KnowledgeDocument {
  id: string;
  title: string;
  source_type: string;
  source_name: string;
  content: string;
  tags: string[];
  chunk_count: number;
  created_at: string;
  updated_at: string;
  chunks?: KnowledgeChunk[];
}

export interface ConversationSearchHit {
  message_id: string;
  conversation_id: string;
  conversation_title: string;
  role: string;
  snippet: string;
  created_at: string;
}

export interface MemorySystemStatus {
  total_memories: number;
  total_knowledge_docs: number;
  total_knowledge_chunks: number;
  total_conversations: number;
  total_messages: number;
  fts5_enabled: boolean;
  auto_save_disabled: boolean;
}

export interface RetrievalQueryResponse {
  queried: boolean;
  query: string;
  retrieval_backend: 'sqlite_fts5' | 'sqlite_like';
  memories: Array<{
    id: string;
    namespace: string;
    category: string;
    title: string;
    content: string;
    importance: number;
    score: number;
  }>;
  knowledge: Array<{
    chunk_id: string;
    document_id: string;
    document_title: string;
    source_type: string;
    chunk_index: number;
    content: string;
    score: number;
  }>;
  total_context_tokens: number;
  formatted_context: string | null;
}

export interface ResearchSource {
  id: string;
  title: string;
  reference: string;
  note: string;
}

export interface ResearchProject {
  id: string;
  title: string;
  summary: string;
  status: 'active' | 'draft' | 'archived';
  tags: string[];
  sources: ResearchSource[];
  notes: string;
  created_at: string;
  updated_at: string;
}

export type ModelProviderType =
  | 'genesis_core'
  | 'local_http'
  | 'gguf_local'
  | 'safetensors_local';

export type ModelAvailabilityStatus =
  | 'placeholder'
  | 'registered'
  | 'connected'
  | 'unreachable';

export type ModelLoadingStatus =
  | 'unloaded'
  | 'staged'
  | 'loaded'
  | 'error';

export interface ModelEntry {
  id: string;
  name: string;
  provider: ModelProviderType;
  model_type: string;
  local_path: string;
  endpoint_url: string;
  status: ModelAvailabilityStatus;
  loading_status: ModelLoadingStatus;
  context_length: number;
  quantization: string;
  parameter_count: string;
  metadata: {
    architecture?: string;
    weights_verified?: boolean;
    notes?: string;
    detected_models?: string[];
    server_model?: string | null;
    last_probe_at?: string;
  };
  created_at: string;
  updated_at: string;
}

export interface SandboxPolicy {
  allow_network: boolean;
  allow_filesystem_write: boolean;
  allow_shell_execution: boolean;
  max_steps: number;
  workspace_scope: string;
}

export interface AgentBlueprint {
  id: string;
  name: string;
  role: string;
  description: string;
  allowed_tools: string[];
  sandbox_policy: SandboxPolicy;
  system_prompt: string;
  status: 'ready' | 'draft' | 'restricted';
  created_at: string;
  updated_at: string;
}

export interface AgentToolDescriptor {
  id: string;
  name: string;
  category:
    | 'file_system'
    | 'document'
    | 'code_execution'
    | 'knowledge'
    | 'memory'
    | 'local_app'
    | 'future_extension';
  description: string;
  risk_level: 'read_only' | 'consequential' | 'reserved_stub';
  requires_approval: boolean;
  safe_retryable: boolean;
  operational: boolean;
  input_schema: Record<string, unknown>;
}

export type AgentTaskStatus =
  | 'planned'
  | 'running'
  | 'awaiting_approval'
  | 'completed'
  | 'failed'
  | 'cancelled';

export type AgentStepStatus =
  | 'pending'
  | 'awaiting_approval'
  | 'approved'
  | 'rejected'
  | 'running'
  | 'completed'
  | 'failed'
  | 'skipped';

export interface AgentTaskSummary {
  id: string;
  agent_id: string;
  agent_name?: string;
  title: string;
  goal: string;
  status: AgentTaskStatus;
  current_step_index: number;
  memory_context: {
    memories: Array<{ id: string; title: string; category: string }>;
    knowledge: Array<{ document_id: string; document_title: string; chunk_index: number }>;
  };
  result_summary: string;
  error_message: string;
  max_retries: number;
  step_count?: number;
  completed_steps?: number;
  pending_approvals?: number;
  created_at: string;
  updated_at: string;
  completed_at: string | null;
}

export interface AgentTaskStep {
  id: string;
  task_id: string;
  step_index: number;
  title: string;
  description: string;
  tool_name: string;
  tool_input: Record<string, unknown>;
  status: AgentStepStatus;
  requires_approval: boolean;
  approval_status: 'not_required' | 'pending' | 'approved' | 'rejected';
  approval_note: string;
  safe_retryable: boolean;
  attempts: number;
  max_attempts: number;
  output: {
    summary?: string;
    data?: Record<string, unknown>;
  };
  error_message: string;
  started_at: string | null;
  completed_at: string | null;
}

export interface AgentExecutionHistoryItem {
  id: string;
  task_id: string;
  step_id: string | null;
  agent_id: string;
  event_type: string;
  tool_name: string;
  detail: string;
  payload: Record<string, unknown>;
  created_at: string;
}

export interface AgentResultReport {
  task_id: string;
  title: string;
  status: AgentTaskStatus;
  completed_steps: number;
  total_steps: number;
  failed_steps: number;
  pending_approvals: number;
  summary: string;
  artifacts_created: Array<{ path: string; bytes: number }>;
  step_outcomes: Array<{
    step_index: number;
    title: string;
    tool_name: string;
    status: string;
    summary: string;
    error?: string;
  }>;
}

export interface AgentTaskDetail {
  task: AgentTaskSummary;
  steps: AgentTaskStep[];
  report: AgentResultReport;
  history: AgentExecutionHistoryItem[];
}

export interface LaboratoryItem {
  id: string;
  kind: 'prompt_template' | 'tokenizer_test' | 'schema_check';
  name: string;
  content: string;
  schema_json: string;
  metrics: Record<string, string | number | boolean>;
  created_at: string;
  updated_at: string;
}

export interface CreatorArtifact {
  id: string;
  title: string;
  artifact_type: 'markdown' | 'code' | 'json' | 'blueprint';
  language: string;
  content: string;
  version: number;
  created_at: string;
  updated_at: string;
}

export interface SystemSettings {
  operator_name: string;
  local_auth_enabled: boolean;
  has_passcode: boolean;
  inference_endpoint_url: string;
  prefer_local_inference: boolean;
  active_model_id: string;
  chat_use_memory: boolean;
  chat_use_knowledge: boolean;
  inference_temperature: number;
  inference_max_tokens: number;
  inference_timeout_ms: number;
  max_upload_mb: number;
  allowed_extensions: string[];
  sandbox_strict_mode: boolean;
  voice_sample_rate: number;
  voice_vad_threshold: number;
  voice_stt_adapter: string;
  voice_tts_adapter: string;
}

export interface StreamStartPayload {
  user_message: Message;
  model_id: string;
  context_tokens_estimated?: number;
  truncated_messages?: number;
  memory_retrieval?: MemoryRetrievalSummary;
}

export interface StreamDeltaPayload {
  delta: string;
  accumulated_length: number;
  model_name?: string;
}

export interface StreamDonePayload {
  assistant_message: Message;
}

export interface StreamErrorPayload {
  error: string;
  assistant_message?: Message;
}

export interface AuthStatusResponse {
  local_auth_enabled: boolean;
  has_passcode: boolean;
  operator_name: string;
  authenticated: boolean;
}

export interface HealthResponse {
  status: 'ok' | 'degraded';
  service: string;
  stage: string;
  runtime: string;
  database: {
    connected: boolean;
    engine: string;
    path: string;
  };
  hardware: {
    platform: string;
    arch: string;
    cpu_model: string;
    cpu_cores: number;
    total_memory_gb: number;
    free_memory_gb: number;
  };
  model_inference: {
    mode: 'demo';
    active_model: string | null;
    external_ai_apis_disabled: boolean;
  };
  timestamp: string;
}

export interface TokenBreakdown {
  token_count: number;
  char_count: number;
  byte_count: number;
  word_count: number;
  estimated_context_pct: number;
  tokens: Array<{ index: number; text: string; bytes: number; id: number }>;
}

export interface GenesisCorePresetSummary {
  vocab_size: number;
  context_length: number;
  d_model: number;
  n_heads: number;
  n_layers: number;
  estimated_parameters?: number;
}

export interface GenesisCoreStatusResponse {
  experimental: true;
  torch_available: boolean;
  runtime_note?: string;
  trained: boolean;
  model_status: 'untrained_experimental' | 'experimental_trained';
  trained_steps: number;
  train_loss: number | null;
  val_loss: number | null;
  checkpoint_path: string;
  checkpoint_exists: boolean;
  tokenizer_path: string;
  tokenizer_exists: boolean;
  architecture: {
    class_name: string;
    tokenizer_class: string;
    presets: Record<string, GenesisCorePresetSummary>;
  };
  training_command: string;
}

