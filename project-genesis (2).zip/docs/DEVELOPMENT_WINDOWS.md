# Windows Local Development Guide — Project Genesis

This guide covers running **Project Genesis** with a **separate React frontend** and **Python FastAPI backend** on a Windows 10/11 development machine.

## Prerequisites

- **Python 3.11+** (`python --version`)
- **Node.js 20+** and **npm** (`node -v`, `npm -v`)
- **Git** (optional)

---

## 1. Backend Setup (Python FastAPI)

Open PowerShell or Windows Terminal in the project root:

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
copy .env.example .env
```

### Initialize the Local SQLite Database

```powershell
python scripts\init_db.py
```

### Start the FastAPI Backend Server

```powershell
uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Verify the backend health endpoint in a browser or PowerShell:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/api/health
```

Interactive OpenAPI documentation is available at `http://127.0.0.1:8000/docs`.

---

## 2. Frontend Setup (React + Vite)

Open a **second** PowerShell window in the project root:

```powershell
npm install
copy .env.example .env
```

Edit `.env` in the project root and point the frontend to the separate FastAPI backend:

```env
VITE_API_BASE_URL=http://127.0.0.1:8000
```

Start the Vite frontend development server:

```powershell
npx vite --port 3000 --host 127.0.0.1
```

Open `http://127.0.0.1:3000` in your browser.

---

## 3. Running Tests

Run the Python backend test suite from `/backend`:

```powershell
cd backend
.\.venv\Scripts\Activate.ps1
pytest
```

Run TypeScript type-checking and production build from the project root:

```powershell
npm run lint
npm run build
```

---

## 4. Connecting a Future Independent Inference Engine

Project Genesis communicates with local inference runtimes through `LocalHttpInferenceAdapter` (`backend/app/ai/local_inference_adapter.py`).

To test with your own local model server (such as `llama.cpp` server, `vLLM`, or a custom PyTorch/FastAPI model service):

1. Start your local model server listening on `http://127.0.0.1:8080` exposing:
   - `GET /health`
   - `POST /v1/chat/completions`
2. Open **Genesis Model Manager** and click **Probe** on **Local Inference Server Adapter**.
3. Open **Genesis System Settings**, enable **Dispatch Genesis Chat prompts to configured local inference endpoint**, and click **Save System Configuration**.
4. Future **GENESIS CORE** in-house weights can be wired directly into `backend/app/ai/genesis_core_adapter.py`.
