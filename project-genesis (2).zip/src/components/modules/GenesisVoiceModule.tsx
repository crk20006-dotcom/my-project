import React, { useEffect, useRef, useState } from 'react';
import { FileAudio, Mic, MicOff, Save, Volume2 } from 'lucide-react';
import { apiClient } from '../../services/apiClient';
import type { SystemSettings } from '../../types/genesis';

interface GenesisVoiceModuleProps {
  settings: SystemSettings | null;
  onSettingsUpdated: (next: SystemSettings) => void;
}

export const GenesisVoiceModule: React.FC<GenesisVoiceModuleProps> = ({
  settings,
  onSettingsUpdated,
}) => {
  const [micActive, setMicActive] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);
  const [rmsLevel, setRmsLevel] = useState(0);
  const [audioFileInfo, setAudioFileInfo] = useState<{
    name: string;
    sizeKb: number;
    durationSec: number;
    sampleRate: number;
    channels: number;
  } | null>(null);

  const [sampleRate, setSampleRate] = useState(settings?.voice_sample_rate ?? 16000);
  const [vadThreshold, setVadThreshold] = useState(settings?.voice_vad_threshold ?? 0.45);
  const [sttAdapter, setSttAdapter] = useState(settings?.voice_stt_adapter ?? 'placeholder_whisper_local');
  const [ttsAdapter, setTtsAdapter] = useState(settings?.voice_tts_adapter ?? 'placeholder_piper_local');
  const [saving, setSaving] = useState(false);
  const [savedMsg, setSavedMsg] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const rafRef = useRef<number | null>(null);

  const stopMic = () => {
    if (rafRef.current) cancelAnimationFrame(rafRef.current);
    streamRef.current?.getTracks().forEach((t) => t.stop());
    void audioCtxRef.current?.close();
    streamRef.current = null;
    audioCtxRef.current = null;
    setMicActive(false);
    setRmsLevel(0);
  };

  useEffect(() => {
    if (!settings) return;
    setSampleRate(settings.voice_sample_rate);
    setVadThreshold(settings.voice_vad_threshold);
    setSttAdapter(settings.voice_stt_adapter);
    setTtsAdapter(settings.voice_tts_adapter);
  }, [settings]);

  useEffect(() => {
    return () => stopMic();
  }, []);

  const startMic = async () => {
    setMicError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const ctx = new AudioContext();
      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = 256;
      source.connect(analyser);

      streamRef.current = stream;
      audioCtxRef.current = ctx;
      setMicActive(true);

      const dataArray = new Uint8Array(analyser.frequencyBinCount);
      const render = () => {
        analyser.getByteTimeDomainData(dataArray);
        let sum = 0;
        for (let i = 0; i < dataArray.length; i++) {
          const v = (dataArray[i] - 128) / 128;
          sum += v * v;
        }
        const rms = Math.sqrt(sum / dataArray.length);
        setRmsLevel(Number((rms * 100).toFixed(1)));

        const canvas = canvasRef.current;
        if (canvas) {
          const g = canvas.getContext('2d');
          if (g) {
            g.fillStyle = '#0A0D12';
            g.fillRect(0, 0, canvas.width, canvas.height);
            g.strokeStyle = '#3B82F6';
            g.lineWidth = 1.75;
            g.beginPath();
            const sliceWidth = canvas.width / dataArray.length;
            let x = 0;
            for (let i = 0; i < dataArray.length; i++) {
              const y = (dataArray[i] / 255) * canvas.height;
              if (i === 0) g.moveTo(x, y);
              else g.lineTo(x, y);
              x += sliceWidth;
            }
            g.stroke();
          }
        }
        rafRef.current = requestAnimationFrame(render);
      };
      render();
    } catch (err) {
      setMicError(
        err instanceof Error
          ? err.message
          : 'Microphone access denied or unavailable in this browser context.'
      );
    }
  };

  const handleInspectAudioFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setMicError(null);
    let ctx: AudioContext | null = null;
    try {
      const buffer = await file.arrayBuffer();
      ctx = new AudioContext();
      const decoded = await ctx.decodeAudioData(buffer);
      setAudioFileInfo({
        name: file.name,
        sizeKb: Number((file.size / 1024).toFixed(1)),
        durationSec: Number(decoded.duration.toFixed(2)),
        sampleRate: decoded.sampleRate,
        channels: decoded.numberOfChannels,
      });
    } catch {
      setMicError('Unable to decode audio file. Upload a valid WAV, MP3, or OGG file.');
    } finally {
      if (ctx) {
        await ctx.close().catch(() => {});
      }
      e.target.value = '';
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setSavedMsg(null);
    try {
      const updated = await apiClient.updateSettings({
        voice_sample_rate: sampleRate,
        voice_vad_threshold: vadThreshold,
        voice_stt_adapter: sttAdapter,
        voice_tts_adapter: ttsAdapter,
      });
      onSettingsUpdated(updated);
      setSavedMsg('Voice pipeline configuration saved.');
    } catch (err) {
      setMicError(err instanceof Error ? err.message : 'Failed to save voice settings.');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="h-full overflow-y-auto px-4 lg:px-8 py-6">
      <div className="max-w-6xl mx-auto space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 pb-5 border-b border-white/[0.08]">
          <div>
            <h2 className="font-display text-xl font-semibold text-slate-100">
              Genesis Voice — Audio Capture & Local Pipeline
            </h2>
            <p className="text-sm text-slate-400 mt-1">
              Test local microphone waveform capture, inspect audio files via Web Audio API, and configure future local STT/TTS adapters.
            </p>
          </div>
          <span className="text-xs text-amber-400">
            STT / TTS Models Not Connected · Audio Hardware Test Active
          </span>
        </div>

        {micError && (
          <div className="p-3.5 rounded-lg bg-red-500/10 border border-red-500/25 text-xs text-red-300">
            {micError}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Live Hardware Waveform Capture */}
          <div className="lg:col-span-7 rounded-xl border border-white/[0.08] bg-[#11161F] p-6 space-y-4">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h3 className="font-display text-base font-semibold text-slate-100">
                  Live Microphone Input Monitor
                </h3>
                <p className="text-xs text-slate-400 mt-0.5 tabular-nums">
                  RMS Signal Level: {rmsLevel}% · VAD Threshold: {Math.round(vadThreshold * 100)}%
                </p>
              </div>
              <button
                type="button"
                onClick={micActive ? stopMic : () => void startMic()}
                className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-lg text-xs font-medium transition-colors cursor-pointer ${
                  micActive
                    ? 'bg-red-600 hover:bg-red-500 text-white'
                    : 'bg-blue-600 hover:bg-blue-500 text-white'
                }`}
              >
                {micActive ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
                <span>{micActive ? 'Stop Capture' : 'Start Mic Test'}</span>
              </button>
            </div>

            <canvas
              ref={canvasRef}
              width={640}
              height={160}
              className="w-full h-40 rounded-lg border border-white/[0.08] bg-[#0A0D12]"
            />

            <div className="pt-3 border-t border-white/[0.08] flex flex-wrap items-center justify-between gap-3">
              <div className="text-xs text-slate-400">
                Or inspect a local audio file (.wav, .mp3, .ogg) without uploading to external servers:
              </div>
              <label className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-lg border border-white/[0.1] bg-[#161C26] hover:bg-[#1E2634] text-xs font-medium text-slate-200 cursor-pointer">
                <FileAudio className="w-3.5 h-3.5" />
                <span>Inspect Audio File</span>
                <input
                  type="file"
                  accept=".wav,.mp3,.ogg,audio/*"
                  onChange={handleInspectAudioFile}
                  className="hidden"
                />
              </label>
            </div>

            {audioFileInfo && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 p-3.5 rounded-lg bg-[#0A0D12] border border-white/[0.08] text-xs">
                <div>
                  <div className="text-slate-500">File</div>
                  <div className="font-mono text-slate-200 truncate mt-0.5">{audioFileInfo.name}</div>
                </div>
                <div>
                  <div className="text-slate-500">Duration</div>
                  <div className="font-mono text-slate-200 tabular-nums mt-0.5">{audioFileInfo.durationSec}s</div>
                </div>
                <div>
                  <div className="text-slate-500">Sample Rate</div>
                  <div className="font-mono text-slate-200 tabular-nums mt-0.5">{audioFileInfo.sampleRate} Hz</div>
                </div>
                <div>
                  <div className="text-slate-500">Channels</div>
                  <div className="font-mono text-slate-200 tabular-nums mt-0.5">{audioFileInfo.channels}</div>
                </div>
              </div>
            )}
          </div>

          {/* Local Pipeline Adapter Configuration */}
          <form
            onSubmit={handleSaveConfig}
            className="lg:col-span-5 rounded-xl border border-white/[0.08] bg-[#11161F] p-6 space-y-4"
          >
            <div className="flex items-center gap-2 font-display text-base font-semibold text-slate-100">
              <Volume2 className="w-4 h-4 text-blue-400" />
              <span>Local Audio Adapter Slots</span>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Target Sample Rate (Hz)</label>
              <select
                value={sampleRate}
                onChange={(e) => setSampleRate(Number(e.target.value))}
                className="w-full px-3 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] text-sm text-slate-100 tabular-nums focus:outline-none"
              >
                <option value={16000}>16,000 Hz (Standard Speech)</option>
                <option value={22050}>22,050 Hz</option>
                <option value={44100}>44,100 Hz</option>
                <option value={48000}>48,000 Hz</option>
              </select>
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5 tabular-nums">
                VAD Activation Threshold ({vadThreshold})
              </label>
              <input
                type="range"
                min={0.1}
                max={0.95}
                step={0.05}
                value={vadThreshold}
                onChange={(e) => setVadThreshold(Number(e.target.value))}
                className="w-full accent-blue-500"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Speech-to-Text Adapter (Placeholder)</label>
              <input
                type="text"
                value={sttAdapter}
                onChange={(e) => setSttAdapter(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] font-mono text-xs text-slate-100 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs text-slate-400 mb-1.5">Text-to-Speech Adapter (Placeholder)</label>
              <input
                type="text"
                value={ttsAdapter}
                onChange={(e) => setTtsAdapter(e.target.value)}
                className="w-full px-3 py-2 rounded-lg bg-[#0A0D12] border border-white/[0.1] font-mono text-xs text-slate-100 focus:outline-none"
              />
            </div>

            {savedMsg && <div className="text-xs text-emerald-400">{savedMsg}</div>}

            <button
              type="submit"
              disabled={saving}
              className="w-full inline-flex items-center justify-center gap-1.5 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 text-xs font-medium text-white cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>{saving ? 'Saving...' : 'Save Audio Configuration'}</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
