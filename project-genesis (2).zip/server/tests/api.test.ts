import assert from 'node:assert/strict';
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import { after, before, describe, it } from 'node:test';
import express from 'express';
import { isLocalInferenceUrlSafe } from '../ai/interfaces.ts';
import { inspectGenesisCheckpointOnDisk } from '../ai/adapters.ts';
import { closeDb, getDb, runInTransaction } from '../db.ts';
import { createApiRouter } from '../routes/api.ts';

describe('Project Genesis Express API & Security Corrections', () => {
  let tmpDir = '';
  let server: http.Server;
  let baseUrl = '';

  before(async () => {
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'genesis-test-'));
    process.env.GENESIS_DB_PATH = path.join(tmpDir, 'genesis.test.db');
    closeDb();

    const app = express();
    app.use(express.json({ limit: '4mb' }));
    app.use('/api', createApiRouter());

    server = await new Promise<http.Server>((resolve) => {
      const s = app.listen(0, '127.0.0.1', () => resolve(s));
    });
    const addr = server.address() as { port: number };
    baseUrl = `http://127.0.0.1:${addr.port}`;
  });

  after(async () => {
    await new Promise<void>((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
    closeDb();
    delete process.env.GENESIS_DB_PATH;
    if (tmpDir && fs.existsSync(tmpDir)) {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });

  it('rejects 0.0.0.0 and external hosts in local inference SSRF guard', () => {
    assert.equal(isLocalInferenceUrlSafe('http://127.0.0.1:8080').valid, true);
    assert.equal(isLocalInferenceUrlSafe('http://localhost:8080').valid, true);
    assert.equal(isLocalInferenceUrlSafe('http://0.0.0.0:8080').valid, false);
    assert.equal(isLocalInferenceUrlSafe('https://example.com/v1').valid, false);
  });

  it('fixes GET /conversations/:id/messages binding and isolates conversation histories', async () => {
    const convARes = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Conv A' }),
    });
    assert.equal(convARes.status, 201);
    const convA = (await convARes.json()) as { id: string };

    const convBRes = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Conv B' }),
    });
    assert.equal(convBRes.status, 201);
    const convB = (await convBRes.json()) as { id: string };

    const msgARes = await fetch(`${baseUrl}/api/conversations/${convA.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Alpha specific prompt', attachments: [] }),
    });
    assert.equal(msgARes.status, 201);

    const msgBRes = await fetch(`${baseUrl}/api/conversations/${convB.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Beta specific prompt', attachments: [] }),
    });
    assert.equal(msgBRes.status, 201);

    const listARes = await fetch(`${baseUrl}/api/conversations/${convA.id}/messages`);
    assert.equal(listARes.status, 200);
    const listA = (await listARes.json()) as Array<{ conversation_id: string; content: string }>;
    assert.equal(listA.length, 2);
    assert.ok(listA.every((m) => m.conversation_id === convA.id));
    assert.equal(listA[0].content, 'Alpha specific prompt');

    const listBRes = await fetch(`${baseUrl}/api/conversations/${convB.id}/messages`);
    assert.equal(listBRes.status, 200);
    const listB = (await listBRes.json()) as Array<{ conversation_id: string; content: string }>;
    assert.equal(listB.length, 2);
    assert.ok(listB.every((m) => m.conversation_id === convB.id));
    assert.equal(listB[0].content, 'Beta specific prompt');
  });

  it('validates attachment limits and previewText length bounds', async () => {
    const convRes = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Attachment Bounds Test' }),
    });
    const conv = (await convRes.json()) as { id: string };

    // > 10 attachments rejected
    const eleven = Array.from({ length: 11 }, (_, i) => ({
      id: `att-${i}`,
      name: `file-${i}.txt`,
      size: 128,
      mimeType: 'text/plain',
      extension: '.txt',
      validated: true,
    }));
    const tooManyRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'too many', attachments: eleven }),
    });
    assert.equal(tooManyRes.status, 400);

    // previewText > 4000 chars rejected
    const longPreviewRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: 'long preview',
        attachments: [
          {
            id: 'att-long',
            name: 'notes.md',
            size: 5000,
            mimeType: 'text/markdown',
            extension: '.md',
            previewText: 'x'.repeat(4001),
            validated: true,
          },
        ],
      }),
    });
    assert.equal(longPreviewRes.status, 400);

    // disallowed extension rejected
    const badExtRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: 'bad ext',
        attachments: [
          {
            id: 'att-bad',
            name: 'malware.exe',
            size: 100,
            mimeType: 'application/octet-stream',
            extension: '.exe',
            validated: true,
          },
        ],
      }),
    });
    assert.equal(badExtRes.status, 400);
  });

  it('returns created_at on PUT /research/:id and atomically increments creator version', async () => {
    const createResearch = await fetch(`${baseUrl}/api/research`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Study 1', summary: 'Initial' }),
    });
    assert.equal(createResearch.status, 201);
    const createdProj = (await createResearch.json()) as { id: string; created_at: string };

    const updateResearch = await fetch(`${baseUrl}/api/research/${createdProj.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Study 1 Updated', summary: 'Updated' }),
    });
    assert.equal(updateResearch.status, 200);
    const updatedProj = (await updateResearch.json()) as { created_at?: string; title: string };
    assert.equal(updatedProj.created_at, createdProj.created_at);
    assert.equal(updatedProj.title, 'Study 1 Updated');

    const createArt = await fetch(`${baseUrl}/api/creator`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Spec', artifact_type: 'markdown', language: 'markdown', content: 'v1' }),
    });
    const art = (await createArt.json()) as { id: string; version: number };
    assert.equal(art.version, 1);

    const upd1 = await fetch(`${baseUrl}/api/creator/${art.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Spec', artifact_type: 'markdown', language: 'markdown', content: 'v2' }),
    });
    const art2 = (await upd1.json()) as { version: number };
    assert.equal(art2.version, 2);

    const upd2 = await fetch(`${baseUrl}/api/creator/${art.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Spec', artifact_type: 'markdown', language: 'markdown', content: 'v3' }),
    });
    const art3 = (await upd2.json()) as { version: number };
    assert.equal(art3.version, 3);
  });

  it('rolls back failed multi-step writes cleanly with runInTransaction', () => {
    const db = getDb();
    const convId = 'conv-rollback-test';
    const now = new Date().toISOString();
    db.prepare(
      'INSERT INTO conversations (id, title, module, model_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)'
    ).run(convId, 'Rollback Test', 'chat', 'genesis-core-placeholder', now, now);

    assert.throws(() => {
      runInTransaction(db, () => {
        db.prepare(
          'INSERT INTO messages (id, conversation_id, role, content, attachments_json, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
        ).run('msg-fail-1', convId, 'user', 'Should roll back', '[]', '{}', now);
        throw new Error('Simulated write failure');
      });
    }, /Simulated write failure/);

    const countRow = db
      .prepare('SELECT COUNT(*) as c FROM messages WHERE conversation_id = ?')
      .get(convId) as { c: number };
    assert.equal(countRow.c, 0);
  });

  it('enforces server-side session auth, passcode verification on changes, logout, expiry, and rate limiting', async () => {
    // Reject short passcode (< 6 chars)
    const shortPassRes = await fetch(`${baseUrl}/api/settings`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ local_auth_enabled: true, new_passcode: '1234' }),
    });
    assert.equal(shortPassRes.status, 400);

    // Enable auth with valid passcode
    const enableRes = await fetch(`${baseUrl}/api/settings`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ local_auth_enabled: true, new_passcode: 'genesis-secret-99' }),
    });
    assert.equal(enableRes.status, 200);
    const enableData = (await enableRes.json()) as { session_token?: string; local_auth_enabled: boolean };
    assert.equal(enableData.local_auth_enabled, true);
    assert.ok(enableData.session_token && enableData.session_token.length >= 32);

    // Public endpoints still respond cleanly without session
    const healthRes = await fetch(`${baseUrl}/api/health`);
    assert.equal(healthRes.status, 200);
    const authStatusUnauth = await fetch(`${baseUrl}/api/auth/status`);
    assert.equal(authStatusUnauth.status, 200);
    const statusBody = (await authStatusUnauth.json()) as { authenticated: boolean; local_auth_enabled: boolean };
    assert.equal(statusBody.local_auth_enabled, true);
    assert.equal(statusBody.authenticated, false);

    // Private endpoints reject unauthenticated access with 401
    for (const [method, url] of [
      ['GET', '/api/conversations'],
      ['GET', '/api/conversations/search?q=test'],
      ['GET', '/api/memory'],
      ['GET', '/api/memory/status'],
      ['GET', '/api/knowledge'],
      ['POST', '/api/retrieval/query'],
      ['GET', '/api/agent-tools'],
      ['GET', '/api/agent-tasks'],
      ['GET', '/api/agent-history'],
      ['GET', '/api/settings'],
      ['GET', '/api/settings/export-db'],
      ['POST', '/api/settings/reset'],
    ] as const) {
      const r = await fetch(`${baseUrl}${url}`, { method });
      assert.equal(r.status, 401, `Expected 401 for unauthenticated ${method} ${url}`);
    }

    // Logout revokes initial session token
    const logoutRes = await fetch(`${baseUrl}/api/auth/logout`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${enableData.session_token}` },
    });
    assert.equal(logoutRes.status, 200);

    const revokedCheck = await fetch(`${baseUrl}/api/conversations`, {
      headers: { Authorization: `Bearer ${enableData.session_token}` },
    });
    assert.equal(revokedCheck.status, 401);

    // Verify passcode establishes a real server session (both cookie and Bearer work)
    const unlockRes = await fetch(`${baseUrl}/api/settings/verify-passcode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ passcode: 'genesis-secret-99' }),
    });
    assert.equal(unlockRes.status, 200);
    const unlockData = (await unlockRes.json()) as { unlocked: boolean; session_token: string };
    assert.equal(unlockData.unlocked, true);
    const setCookieHeader = unlockRes.headers.get('set-cookie') || '';
    assert.ok(setCookieHeader.includes('genesis_session='));
    assert.ok(setCookieHeader.toLowerCase().includes('httponly'));

    const cookiePair = setCookieHeader.split(';')[0];
    const cookieAuthedRes = await fetch(`${baseUrl}/api/settings`, {
      headers: { Cookie: cookiePair },
    });
    assert.equal(cookieAuthedRes.status, 200);

    // Changing/disabling auth without current_passcode is rejected (403)
    const disableNoPassRes = await fetch(`${baseUrl}/api/settings`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${unlockData.session_token}`,
      },
      body: JSON.stringify({ local_auth_enabled: false }),
    });
    assert.equal(disableNoPassRes.status, 403);

    // Expired session in SQLite is rejected (401)
    const db = getDb();
    db.prepare("UPDATE sessions SET expires_at = '2000-01-01T00:00:00.000Z'").run();
    const expiredRes = await fetch(`${baseUrl}/api/conversations`, {
      headers: { Authorization: `Bearer ${unlockData.session_token}` },
    });
    assert.equal(expiredRes.status, 401);

    // Rate limiter blocks after 5 failed passcode attempts with 429 + Retry-After
    for (let i = 0; i < 5; i++) {
      const failRes = await fetch(`${baseUrl}/api/settings/verify-passcode`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ passcode: `wrong-attempt-${i}` }),
      });
      assert.equal(failRes.status, 401);
    }

    const throttledRes = await fetch(`${baseUrl}/api/settings/verify-passcode`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ passcode: 'genesis-secret-99' }),
    });
    assert.equal(throttledRes.status, 429);
    assert.ok(Number(throttledRes.headers.get('retry-after')) >= 1);
  });
});

describe('Project Genesis Step 04 — Inference Engine, Streaming & Mocked Local Server', () => {
  let tmpDir = '';
  let server: http.Server;
  let baseUrl = '';
  let mockLlmServer: http.Server;
  let mockLlmUrl = '';

  let mockMode: 'normal' | 'sse' | 'slow_sse' | 'invalid_json' | 'http_500' = 'normal';
  type CapturedChatRequest = {
    model?: string;
    messages?: Array<{ role: string; content: string }>;
    temperature?: number;
    max_tokens?: number;
    stream?: boolean;
  };
  let lastCapturedRequest: CapturedChatRequest | null = null;
  const getCapturedRequest = (): CapturedChatRequest | null => lastCapturedRequest;
  let slowStreamAbortedByServer = false;

  before(async () => {
    // 1. Mocked OpenAI-compatible local inference server on 127.0.0.1:0 (NOT a real AI model)
    mockLlmServer = http.createServer(async (req, res) => {
      if (req.method === 'GET' && req.url === '/health') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'ok', slots_idle: 1 }));
        return;
      }
      if (req.method === 'GET' && req.url === '/v1/models') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ object: 'list', data: [{ id: 'mock-local-qwen-7b.gguf' }] }));
        return;
      }
      if (req.method === 'POST' && req.url === '/v1/chat/completions') {
        const chunks: Buffer[] = [];
        for await (const c of req) chunks.push(c as Buffer);
        lastCapturedRequest = JSON.parse(Buffer.concat(chunks).toString('utf8')) as typeof lastCapturedRequest;

        if (mockMode === 'http_500') {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'simulated inference crash' }));
          return;
        }
        if (mockMode === 'invalid_json') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end('{not-valid-json');
          return;
        }
        if (mockMode === 'sse') {
          res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            Connection: 'keep-alive',
          });
          const tokens = ['Hello ', 'from ', 'mock ', 'local ', 'SSE!'];
          for (const tok of tokens) {
            res.write(
              `data: ${JSON.stringify({
                model: 'mock-local-qwen-7b.gguf',
                choices: [{ delta: { content: tok }, finish_reason: null }],
              })}\n\n`
            );
            await new Promise((r) => setTimeout(r, 10));
          }
          res.write(
            `data: ${JSON.stringify({
              model: 'mock-local-qwen-7b.gguf',
              choices: [{ delta: {}, finish_reason: 'stop' }],
              usage: { prompt_tokens: 12, completion_tokens: 5 },
            })}\n\n`
          );
          res.write('data: [DONE]\n\n');
          res.end();
          return;
        }
        if (mockMode === 'slow_sse') {
          slowStreamAbortedByServer = false;
          res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache',
            Connection: 'keep-alive',
          });
          req.on('close', () => {
            slowStreamAbortedByServer = true;
          });
          res.write(
            `data: ${JSON.stringify({
              model: 'mock-local-qwen-7b.gguf',
              choices: [{ delta: { content: 'Partial chunk 1. ' } }],
            })}\n\n`
          );
          await new Promise((r) => setTimeout(r, 40));
          if (!res.destroyed) {
            res.write(
              `data: ${JSON.stringify({
                model: 'mock-local-qwen-7b.gguf',
                choices: [{ delta: { content: 'Partial chunk 2. ' } }],
              })}\n\n`
            );
          }
          // Hold open until caller cancels or test timeout finishes
          for (let i = 0; i < 30; i++) {
            if (slowStreamAbortedByServer || res.destroyed) break;
            await new Promise((r) => setTimeout(r, 50));
          }
          if (!res.destroyed) res.end();
          return;
        }

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(
          JSON.stringify({
            model: 'mock-local-qwen-7b.gguf',
            choices: [{ message: { content: 'Mocked local completion ok.' }, finish_reason: 'stop' }],
            usage: { prompt_tokens: 10, completion_tokens: 4 },
          })
        );
        return;
      }

      res.writeHead(404);
      res.end();
    });

    await new Promise<void>((resolve) => {
      mockLlmServer.listen(0, '127.0.0.1', () => resolve());
    });
    const llmAddr = mockLlmServer.address() as { port: number };
    mockLlmUrl = `http://127.0.0.1:${llmAddr.port}`;

    // 2. Fresh Express + isolated SQLite DB
    tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'genesis-step04-'));
    process.env.GENESIS_DB_PATH = path.join(tmpDir, 'genesis.step04.db');
    closeDb();

    const app = express();
    app.use(express.json({ limit: '4mb' }));
    app.use('/api', createApiRouter());

    server = await new Promise<http.Server>((resolve) => {
      const s = app.listen(0, '127.0.0.1', () => resolve(s));
    });
    const addr = server.address() as { port: number };
    baseUrl = `http://127.0.0.1:${addr.port}`;
  });

  after(async () => {
    await new Promise<void>((resolve, reject) => {
      server.close((err) => (err ? reject(err) : resolve()));
    });
    await new Promise<void>((resolve, reject) => {
      mockLlmServer.close((err) => (err ? reject(err) : resolve()));
    });
    closeDb();
    delete process.env.GENESIS_DB_PATH;
    if (tmpDir && fs.existsSync(tmpDir)) {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  });

  it('validates loopback SSRF on PUT /api/models/:id and probes mocked local server model identity', async () => {
    const blocked = await fetch(`${baseUrl}/api/models/local-inference-http`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ endpoint_url: 'https://api.openai.com' }),
    });
    assert.equal(blocked.status, 400);

    const zeroBlocked = await fetch(`${baseUrl}/api/models/local-inference-http`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ endpoint_url: 'http://0.0.0.0:8080' }),
    });
    assert.equal(zeroBlocked.status, 400);

    const updated = await fetch(`${baseUrl}/api/models/local-inference-http`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ endpoint_url: mockLlmUrl, context_length: 1024 }),
    });
    assert.equal(updated.status, 200);
    const updatedModel = (await updated.json()) as { endpoint_url: string; context_length: number };
    assert.equal(updatedModel.endpoint_url, mockLlmUrl);
    assert.equal(updatedModel.context_length, 1024);

    const probeRes = await fetch(`${baseUrl}/api/models/local-inference-http/probe`, {
      method: 'POST',
    });
    assert.equal(probeRes.status, 200);
    const probe = (await probeRes.json()) as {
      reachable: boolean;
      status: string;
      server_model: string;
      detected_models: string[];
    };
    assert.equal(probe.reachable, true);
    assert.equal(probe.status, 'connected');
    assert.equal(probe.server_model, 'mock-local-qwen-7b.gguf');
    assert.deepEqual(probe.detected_models, ['mock-local-qwen-7b.gguf']);
  });

  it('rejects unknown model_id (404), packs context history to limit, and forwards inference params', async () => {
    const badConv = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Bad Model', model_id: 'nonexistent-model' }),
    });
    assert.equal(badConv.status, 404);

    const convRes = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Mocked Inference Thread', model_id: 'local-inference-http' }),
    });
    assert.equal(convRes.status, 201);
    const conv = (await convRes.json()) as { id: string; model_id: string };
    assert.equal(conv.model_id, 'local-inference-http');

    // Insert long old messages directly to test context truncation against context_length=1024
    const db = getDb();
    const longFiller = 'word '.repeat(280);
    const t0 = new Date(Date.now() - 5000).toISOString();
    const t1 = new Date(Date.now() - 4000).toISOString();
    db.prepare(
      'INSERT INTO messages (id, conversation_id, role, content, attachments_json, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run('old-1', conv.id, 'user', `OLD_DROPPED_1 ${longFiller}`, '[]', '{}', t0);
    db.prepare(
      'INSERT INTO messages (id, conversation_id, role, content, attachments_json, metadata_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)'
    ).run('old-2', conv.id, 'assistant', `OLD_DROPPED_2 ${longFiller}`, '[]', '{}', t1);

    mockMode = 'normal';
    const msgRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: 'Latest short question',
        attachments: [],
        temperature: 0.65,
        max_tokens: 256,
        timeout_ms: 8000,
      }),
    });
    assert.equal(msgRes.status, 201);
    const payload = (await msgRes.json()) as {
      assistant_message: {
        content: string;
        metadata: { mode: string; truncated_messages: number; model_id: string };
      };
    };
    assert.equal(payload.assistant_message.content, 'Mocked local completion ok.');
    assert.equal(payload.assistant_message.metadata.mode, 'local_inference');
    assert.equal(payload.assistant_message.metadata.model_id, 'local-inference-http');
    assert.ok(payload.assistant_message.metadata.truncated_messages >= 1);
    assert.ok(lastCapturedRequest);
    assert.equal(lastCapturedRequest.temperature, 0.65);
    assert.equal(lastCapturedRequest.max_tokens, 256);
    assert.equal(lastCapturedRequest.messages?.some((m) => m.content.includes('OLD_DROPPED_1')), false);
    assert.equal(lastCapturedRequest.messages?.at(-1)?.content, 'Latest short question');

    // Placeholder switch keeps Demo Mode and does not call mocked HTTP server
    const switchRes = await fetch(`${baseUrl}/api/conversations/${conv.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ model_id: 'genesis-core-placeholder' }),
    });
    assert.equal(switchRes.status, 200);
    lastCapturedRequest = null;
    const demoMsgRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Placeholder check', attachments: [] }),
    });
    assert.equal(demoMsgRes.status, 201);
    const demoMsg = (await demoMsgRes.json()) as {
      assistant_message: { metadata: { mode: string; finish_reason: string; diagnostic: boolean } };
    };
    assert.equal(demoMsg.assistant_message.metadata.mode, 'demo');
    assert.equal(demoMsg.assistant_message.metadata.finish_reason, 'not_connected');
    assert.equal(demoMsg.assistant_message.metadata.diagnostic, true);
    assert.equal(lastCapturedRequest, null);
  });

  it('handles HTTP 500, invalid JSON, and unreachable endpoints without fabricating completions', async () => {
    const convRes = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Failure Resilience', model_id: 'local-inference-http' }),
    });
    const conv = (await convRes.json()) as { id: string };

    mockMode = 'http_500';
    const err500 = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Trigger 500', attachments: [] }),
    });
    assert.equal(err500.status, 201);
    const body500 = (await err500.json()) as {
      assistant_message: { content: string; metadata: { mode: string; diagnostic: boolean } };
    };
    assert.equal(body500.assistant_message.metadata.mode, 'demo');
    assert.equal(body500.assistant_message.metadata.diagnostic, true);
    assert.match(body500.assistant_message.content, /HTTP 500/);

    mockMode = 'invalid_json';
    const errJson = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Trigger malformed JSON', attachments: [] }),
    });
    assert.equal(errJson.status, 201);
    const bodyJson = (await errJson.json()) as {
      assistant_message: { content: string; metadata: { mode: string; diagnostic: boolean } };
    };
    assert.equal(bodyJson.assistant_message.metadata.mode, 'demo');
    assert.match(bodyJson.assistant_message.content, /invalid JSON/i);

    // Unreachable local port test
    await fetch(`${baseUrl}/api/models/local-inference-http`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ endpoint_url: 'http://127.0.0.1:59999' }),
    });
    const errConn = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Trigger unreachable', attachments: [] }),
    });
    assert.equal(errConn.status, 201);
    const bodyConn = (await errConn.json()) as {
      assistant_message: { metadata: { mode: string; diagnostic: boolean } };
    };
    assert.equal(bodyConn.assistant_message.metadata.mode, 'demo');
    assert.equal(bodyConn.assistant_message.metadata.diagnostic, true);

    // Restore mockLlmUrl
    await fetch(`${baseUrl}/api/models/local-inference-http`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ endpoint_url: mockLlmUrl }),
    });
  });

  it('streams SSE deltas and persists partial output when cancelled mid-stream', async () => {
    const convRes = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'SSE Streaming Thread', model_id: 'local-inference-http' }),
    });
    const conv = (await convRes.json()) as { id: string };

    // 1. Full SSE stream completion
    mockMode = 'sse';
    const streamRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages/stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Stream tokens please', attachments: [] }),
    });
    assert.equal(streamRes.status, 200);
    assert.match(streamRes.headers.get('content-type') || '', /text\/event-stream/);
    const rawSse = await streamRes.text();
    assert.match(rawSse, /event: start/);
    assert.match(rawSse, /event: delta/);
    assert.match(rawSse, /event: done/);
    assert.match(rawSse, /Hello from mock local SSE!/);

    // 2. Client abort cancellation persists partial response cleanly
    mockMode = 'slow_sse';
    const ac = new AbortController();
    const cancelRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages/stream`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: 'Start and cancel', attachments: [] }),
      signal: ac.signal,
    });
    assert.equal(cancelRes.status, 200);
    const reader = cancelRes.body!.getReader();
    const decoder = new TextDecoder();
    let seenChunk1 = false;
    while (!seenChunk1) {
      const { done, value } = await reader.read();
      if (done) break;
      const chunkText = decoder.decode(value);
      if (chunkText.includes('Partial chunk 1.')) {
        seenChunk1 = true;
        ac.abort();
        break;
      }
    }
    assert.equal(seenChunk1, true);

    // Wait briefly for server on('close') transaction commit
    await new Promise((r) => setTimeout(r, 250));
    const listRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`);
    const msgs = (await listRes.json()) as Array<{
      role: string;
      content: string;
      metadata: { partial?: boolean; finish_reason?: string };
    }>;
    const cancelledAssistant = msgs.at(-1)!;
    assert.equal(cancelledAssistant.role, 'assistant');
    assert.match(cancelledAssistant.content, /Partial chunk 1\./);
    assert.equal(cancelledAssistant.metadata.finish_reason, 'cancelled');
    assert.equal(cancelledAssistant.metadata.partial, true);
  });

  it('reports untrained experimental Genesis Core status and inspects sidecar checkpoint metadata cleanly', async () => {
    const statusRes = await fetch(`${baseUrl}/api/genesis-core/status`);
    assert.equal(statusRes.status, 200);
    const status = (await statusRes.json()) as {
      experimental: boolean;
      trained: boolean;
      model_status: string;
      trained_steps: number;
      architecture: { class_name: string; tokenizer_class: string; presets: Record<string, unknown> };
    };
    assert.equal(status.experimental, true);
    assert.equal(status.trained, false);
    assert.equal(status.model_status, 'untrained_experimental');
    assert.equal(status.trained_steps, 0);
    assert.equal(status.architecture.class_name, 'GenesisCoreTransformer');
    assert.equal(status.architecture.tokenizer_class, 'GenesisByteBPETokenizer');
    assert.ok(status.architecture.presets.cpu_nano);

    // Verify local checkpoint + sidecar metadata detection without executing external APIs
    const tempCkptDir = fs.mkdtempSync(path.join(os.tmpdir(), 'genesis-ckpt-'));
    try {
      const ptPath = path.join(tempCkptDir, 'latest.pt');
      const metaPath = path.join(tempCkptDir, 'latest.meta.json');
      fs.writeFileSync(ptPath, 'stub-pt');
      fs.writeFileSync(
        metaPath,
        JSON.stringify({
          experimental: true,
          trained_steps: 25,
          train_loss: 2.15,
          val_loss: 2.28,
        })
      );
      const inspected = inspectGenesisCheckpointOnDisk(ptPath, path.join(tempCkptDir, 'tokenizer.json'));
      assert.equal(inspected.experimental, true);
      assert.equal(inspected.checkpoint_exists, true);
      assert.equal(inspected.trained, true);
      assert.equal(inspected.model_status, 'experimental_trained');
      assert.equal(inspected.trained_steps, 25);
    } finally {
      fs.rmSync(tempCkptDir, { recursive: true, force: true });
    }
  });

  it('implements Memory & Knowledge CRUD, secret rejection, FTS5 search, DB restart persistence, auth, and chat inference integration', async () => {
    // 1. Memory create + privacy/secret guards + explicit approval requirement
    const unapproved = await fetch(`${baseUrl}/api/memory`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        namespace: 'semantic',
        category: 'fact',
        title: 'Unapproved Attempt',
        content: 'Should not save without approval.',
        tags: [],
        importance: 3,
        approved: false,
      }),
    });
    assert.equal(unapproved.status, 400);

    const secretRejected = await fetch(`${baseUrl}/api/memory`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        namespace: 'semantic',
        category: 'fact',
        title: 'Secret Leak Attempt',
        content: 'Use api_key=super_secret_value_12345 for deployment',
        tags: [],
        importance: 3,
        approved: true,
      }),
    });
    assert.equal(secretRejected.status, 400);

    const createdMemRes = await fetch(`${baseUrl}/api/memory`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        namespace: 'project',
        category: 'constraint',
        title: 'Genesis Runtime Constraint',
        content: 'Genesis platform targets Windows desktop hardware with 16 GB RAM budget.',
        tags: ['windows', 'hardware'],
        importance: 5,
        approved: true,
      }),
    });
    assert.equal(createdMemRes.status, 201);
    const createdMem = (await createdMemRes.json()) as { id: string; category: string; title: string };
    assert.equal(createdMem.category, 'constraint');

    // Update memory
    const updatedMemRes = await fetch(`${baseUrl}/api/memory/${createdMem.id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Genesis Desktop RAM Constraint',
        content: 'Genesis runs CPU-first workflows cleanly within 16 GB Windows RAM.',
        importance: 5,
      }),
    });
    assert.equal(updatedMemRes.status, 200);
    const updatedMem = (await updatedMemRes.json()) as { title: string; content: string };
    assert.equal(updatedMem.title, 'Genesis Desktop RAM Constraint');

    // 2. Knowledge Base create (chunking) + secret guard + search + update + delete
    const kbSecret = await fetch(`${baseUrl}/api/knowledge`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Bad Credentials Note',
        source_type: 'note',
        content: '-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA',
        tags: [],
      }),
    });
    assert.equal(kbSecret.status, 400);

    const longGuide = [
      'Project Genesis runs FastAPI on loopback port 8000 and Express on port 3000.',
      'SQLite FTS5 provides lightweight keyword search over local knowledge documents without cloud vector databases.',
      'Additional operational notes: checkpoint artifacts live under data/checkpoints/genesis_core.',
    ].join('\n\n') + '\n\n' + 'Background details about Genesis modular adapters. '.repeat(25);

    const createdDocRes = await fetch(`${baseUrl}/api/knowledge`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Genesis Architecture Handbook',
        source_type: 'markdown',
        source_name: 'handbook.md',
        content: longGuide,
        tags: ['architecture', 'sqlite'],
      }),
    });
    assert.equal(createdDocRes.status, 201);
    const createdDoc = (await createdDocRes.json()) as { id: string; chunk_count: number };
    assert.ok(createdDoc.chunk_count >= 2);

    // 3. Retrieval Query returns matching User Memory & Knowledge chunks, and returns empty on unrelated query
    const queryMatchRes = await fetch(`${baseUrl}/api/retrieval/query`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: 'Windows RAM budget and FastAPI port 8000' }),
    });
    assert.equal(queryMatchRes.status, 200);
    const queryMatch = (await queryMatchRes.json()) as {
      memories: Array<{ id: string; title: string }>;
      knowledge: Array<{ document_id: string; document_title: string }>;
      formatted_context: string | null;
    };
    assert.ok(queryMatch.memories.some((m) => m.id === createdMem.id));
    assert.ok(queryMatch.knowledge.some((k) => k.document_id === createdDoc.id));
    assert.match(queryMatch.formatted_context || '', /\[Approved User Memory\]/);
    assert.match(queryMatch.formatted_context || '', /\[Knowledge Base Excerpts\]/);

    const noMatchRes = await fetch(`${baseUrl}/api/retrieval/query`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: 'xylophone nebula quasar' }),
    });
    const noMatch = (await noMatchRes.json()) as {
      memories: unknown[];
      knowledge: unknown[];
      formatted_context: string | null;
    };
    assert.equal(noMatch.memories.length, 0);
    assert.equal(noMatch.knowledge.length, 0);
    assert.equal(noMatch.formatted_context, null);

    // 4. Restart / DB close-and-reopen persistence verification
    closeDb();
    const reopenedMemRes = await fetch(`${baseUrl}/api/memory?q=Desktop`);
    assert.equal(reopenedMemRes.status, 200);
    const reopenedMems = (await reopenedMemRes.json()) as Array<{ id: string }>;
    assert.ok(reopenedMems.some((m) => m.id === createdMem.id));

    // 5. Chat inference integration + strict separation from Conversation History
    const convRes = await fetch(`${baseUrl}/api/conversations`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: 'Memory Context Injection Test', model_id: 'local-inference-http' }),
    });
    const conv = (await convRes.json()) as { id: string };

    mockMode = 'normal';
    lastCapturedRequest = null;
    const chatRes = await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: 'What RAM limit applies on Windows and which port does FastAPI use?',
        attachments: [],
        use_memory: true,
        use_knowledge: true,
      }),
    });
    assert.equal(chatRes.status, 201);
    const chatPayload = (await chatRes.json()) as {
      assistant_message: {
        metadata: {
          memory_retrieval?: {
            queried: boolean;
            memories_used: Array<{ id: string }>;
            knowledge_used: Array<{ document_id: string }>;
          };
        };
      };
    };
    assert.equal(chatPayload.assistant_message.metadata.memory_retrieval?.queried, true);
    assert.ok(
      chatPayload.assistant_message.metadata.memory_retrieval?.memories_used.some(
        (m) => m.id === createdMem.id
      )
    );
    assert.ok(
      chatPayload.assistant_message.metadata.memory_retrieval?.knowledge_used.some(
        (k) => k.document_id === createdDoc.id
      )
    );
    assert.ok(
      getCapturedRequest()?.messages?.some(
        (m) =>
          m.role === 'system' &&
          m.content.includes('Genesis Desktop RAM Constraint') &&
          m.content.includes('FastAPI on loopback port 8000')
      )
    );

    // Ensure regular chat turn was NOT auto-saved into User Memory, yet IS searchable in Conversation History
    const allMemoriesAfterChat = (await (await fetch(`${baseUrl}/api/memory`)).json()) as Array<{
      content: string;
    }>;
    assert.equal(
      allMemoriesAfterChat.some((m) => m.content.includes('What RAM limit applies on Windows')),
      false
    );

    const convSearchRes = await fetch(
      `${baseUrl}/api/conversations/search?q=${encodeURIComponent('RAM limit applies')}`
    );
    assert.equal(convSearchRes.status, 200);
    const convSearchBody = (await convSearchRes.json()) as {
      matches: Array<{ conversation_id: string; snippet: string }>;
    };
    assert.ok(convSearchBody.matches.some((m) => m.conversation_id === conv.id));

    // Toggle use_memory/use_knowledge off prevents system injection
    lastCapturedRequest = null;
    await fetch(`${baseUrl}/api/conversations/${conv.id}/messages`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        content: 'Windows RAM budget and FastAPI port 8000 again',
        attachments: [],
        use_memory: false,
        use_knowledge: false,
      }),
    });
    assert.equal(getCapturedRequest()?.messages?.some((m) => m.role === 'system'), false);

    // 6. Status endpoint + Knowledge/Memory delete cleans up FTS indexes
    const statusRes = await fetch(`${baseUrl}/api/memory/status`);
    assert.equal(statusRes.status, 200);
    const memStatus = (await statusRes.json()) as {
      total_memories: number;
      total_knowledge_docs: number;
      auto_save_disabled: boolean;
    };
    assert.ok(memStatus.total_memories >= 1);
    assert.ok(memStatus.total_knowledge_docs >= 1);
    assert.equal(memStatus.auto_save_disabled, true);

    assert.equal((await fetch(`${baseUrl}/api/knowledge/${createdDoc.id}`, { method: 'DELETE' })).status, 200);
    assert.equal((await fetch(`${baseUrl}/api/memory/${createdMem.id}`, { method: 'DELETE' })).status, 200);

    const afterDelete = (await (
      await fetch(`${baseUrl}/api/retrieval/query`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: 'Windows RAM budget and FastAPI port 8000' }),
      })
    ).json()) as { memories: unknown[]; knowledge: unknown[] };
    assert.equal(afterDelete.memories.length, 0);
    assert.equal(afterDelete.knowledge.length, 0);
  });

  it('orchestrates Step 07 Agent OS (planning, memory context, approval gating, sandbox security, history, and chat settings)', async () => {
    const { AgentToolRegistry } = await import('../agent/toolRegistry.ts');
    const { TaskExecutionEngine } = await import('../agent/taskExecutor.ts');
    const { TaskStateManager } = await import('../agent/taskStateManager.ts');
    const { AgentResultReporter } = await import('../agent/resultReporter.ts');

    // 1. Tool registry lists operational tools and reserved future stubs
    const toolsRes = await fetch(`${baseUrl}/api/agent-tools`);
    assert.equal(toolsRes.status, 200);
    const tools = (await toolsRes.json()) as Array<{
      id: string;
      operational: boolean;
      requires_approval: boolean;
      risk_level: string;
    }>;
    assert.ok(tools.some((t) => t.id === 'read_workspace_file' && t.operational && !t.requires_approval));
    assert.ok(tools.some((t) => t.id === 'create_document' && t.operational && t.requires_approval));
    assert.ok(tools.some((t) => t.id === 'run_restricted_code' && t.operational && t.requires_approval));
    assert.ok(tools.some((t) => t.id === 'web_search_future' && !t.operational && t.risk_level === 'reserved_stub'));
    assert.ok(tools.some((t) => t.id === 'world_intelligence_future' && !t.operational));

    // 2. Agent registration strips reserved future stubs and enforces sandbox policy
    const createAgentRes = await fetch(`${baseUrl}/api/agents`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: 'Step 07 Test Orchestrator',
        role: 'Verification Operator',
        description: 'Automated Step 07 test agent.',
        allowed_tools: [
          'retrieve_memory',
          'retrieve_knowledge',
          'read_workspace_file',
          'local_workspace_ops',
          'run_restricted_code',
          'create_document',
          'web_search_future',
        ],
        sandbox_policy: { max_steps: 6 },
      }),
    });
    assert.equal(createAgentRes.status, 201);
    const agent = (await createAgentRes.json()) as {
      id: string;
      allowed_tools: string[];
      sandbox_policy: { allow_network: boolean; allow_shell_execution: boolean; allow_filesystem_write: boolean };
    };
    assert.equal(agent.allowed_tools.includes('web_search_future'), false);
    assert.equal(agent.sandbox_policy.allow_network, false);
    assert.equal(agent.sandbox_policy.allow_shell_execution, false);
    assert.equal(agent.sandbox_policy.allow_filesystem_write, true);

    // 3. Seed approved memory + knowledge document for Agent planning integration
    const memRes = await fetch(`${baseUrl}/api/memory`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        namespace: 'project',
        category: 'instruction',
        title: 'Agent Output Verification Format',
        content: 'Agent task reports should reference workspace validation metrics clearly.',
        tags: ['agent', 'verification'],
        importance: 5,
        approved: true,
      }),
    });
    assert.equal(memRes.status, 201);
    const mem = (await memRes.json()) as { id: string };

    const kbRes = await fetch(`${baseUrl}/api/knowledge`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        title: 'Agent Sandbox Architecture Spec',
        source_type: 'markdown',
        source_name: 'agent_spec.md',
        content: 'Genesis Agent OS workspace metrics and verification report guidelines require operator approval before document creation or code evaluation.',
        tags: ['agent', 'sandbox'],
      }),
    });
    assert.equal(kbRes.status, 201);
    const kb = (await kbRes.json()) as { id: string };

    // Secret detection on task creation
    const secretTaskRes = await fetch(`${baseUrl}/api/agent-tasks`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        agent_id: agent.id,
        goal: 'Write api_key=sk-proj-secret1234567890abcdef into file',
      }),
    });
    assert.equal(secretTaskRes.status, 400);

    const uniqueReportName = `step07_test_report_${process.pid}.md`;
    const createdDocDiskPath = path.resolve(process.cwd(), 'data', 'agent_workspace', 'documents', uniqueReportName);

    try {
      // 4. Create & plan task
      const planRes = await fetch(`${baseUrl}/api/agent-tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent_id: agent.id,
          title: 'Workspace Validation & Report Brief',
          goal: 'Inspect workspace validation metrics, compute total units, and create a verification report.',
          target_file_path: 'workspace_readme.txt',
          document_filename: uniqueReportName,
          code_snippet: 'const units = 6 * 7; console.log("computed", units); ({ total_units: units });',
          auto_run: false,
        }),
      });
      if (planRes.status !== 201) {
        console.error('PLAN RES ERROR:', await planRes.text());
      }
      assert.equal(planRes.status, 201);
      const planned = (await planRes.json()) as {
        task: {
          id: string;
          status: string;
          memory_context: { memories: Array<{ id: string }>; knowledge: Array<{ document_id: string }> };
        };
        steps: Array<{ id: string; tool_name: string; status: string; requires_approval: boolean }>;
      };
      assert.equal(planned.task.status, 'planned');
      assert.ok(planned.steps.length >= 4);
      assert.ok(planned.task.memory_context.memories.some((m) => m.id === mem.id));
      assert.ok(planned.task.memory_context.knowledge.some((k) => k.document_id === kb.id));

      // 5. Run task sequentially -> pauses at first consequential step (run_restricted_code)
      const firstRunRes = await fetch(`${baseUrl}/api/agent-tasks/${planned.task.id}/run`, { method: 'POST' });
      assert.equal(firstRunRes.status, 200);
      const afterFirstRun = (await firstRunRes.json()) as {
        task: { status: string };
        steps: Array<{ id: string; tool_name: string; status: string; approval_status: string }>;
      };
      if (afterFirstRun.task.status === 'failed') {
        const failTask = afterFirstRun as unknown as { task: { error_message: string }; steps: Array<{ error_message: string }> };
        console.error('NODE TASK FAILED:', failTask.task.error_message, failTask.steps.map(s => s.error_message));
      }
      assert.equal(afterFirstRun.task.status, 'awaiting_approval');
      const codeStep = afterFirstRun.steps.find((s) => s.tool_name === 'run_restricted_code')!;
      assert.equal(codeStep.status, 'awaiting_approval');
      assert.equal(codeStep.approval_status, 'pending');
      assert.equal(afterFirstRun.steps.find((s) => s.tool_name === 'read_workspace_file')?.status, 'completed');

      // 6. Approve code step -> executes VM snippet & pauses at create_document
      const approveCodeRes = await fetch(
        `${baseUrl}/api/agent-tasks/${planned.task.id}/steps/${codeStep.id}/approve`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ approved: true, note: 'Verified deterministic snippet', resume: true }),
        }
      );
      assert.equal(approveCodeRes.status, 200);
      const afterCodeApprove = (await approveCodeRes.json()) as {
        task: { status: string };
        steps: Array<{
          id: string;
          tool_name: string;
          status: string;
          output: { data?: { result?: string; stdout?: string[] } };
        }>;
      };
      const doneCodeStep = afterCodeApprove.steps.find((s) => s.id === codeStep.id)!;
      assert.equal(doneCodeStep.status, 'completed');
      assert.match(doneCodeStep.output.data?.result || '', /42/);
      assert.equal(afterCodeApprove.task.status, 'awaiting_approval');
      const docStep = afterCodeApprove.steps.find((s) => s.tool_name === 'create_document')!;
      assert.equal(docStep.status, 'awaiting_approval');

      // 7. Approve document creation -> writes document inside ./data/agent_workspace/documents & completes task
      const approveDocRes = await fetch(
        `${baseUrl}/api/agent-tasks/${planned.task.id}/steps/${docStep.id}/approve`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ approved: true, note: 'Approved report file creation', resume: true }),
        }
      );
      assert.equal(approveDocRes.status, 200);
      const completedDetail = (await approveDocRes.json()) as {
        task: { status: string };
        report: { status: string; completed_steps: number; total_steps: number; artifacts_created: string[] };
        history: Array<{ event_type: string }>;
      };
      assert.equal(completedDetail.task.status, 'completed');
      assert.equal(completedDetail.report.completed_steps, completedDetail.report.total_steps);
      assert.ok(completedDetail.report.artifacts_created.some((art) => art.path.includes(uniqueReportName)));
      assert.equal(fs.existsSync(createdDocDiskPath), true);
      assert.ok(completedDetail.history.some((h) => h.event_type === 'plan_generated'));
      assert.ok(completedDetail.history.some((h) => h.event_type === 'approval_granted'));
      assert.ok(completedDetail.history.some((h) => h.event_type === 'task_completed'));

      // 8. Save task result to User Memory requires explicit approved: true
      const unapprovedMemSave = await fetch(`${baseUrl}/api/agent-tasks/${planned.task.id}/save-memory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ approved: false, title: 'Blocked' }),
      });
      assert.equal(unapprovedMemSave.status, 400);

      const approvedMemSave = await fetch(`${baseUrl}/api/agent-tasks/${planned.task.id}/save-memory`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          approved: true,
          title: 'Step 07 Verification Outcome',
          category: 'fact',
          tags: ['agent-result', 'step-07'],
        }),
      });
      assert.equal(approvedMemSave.status, 201);
      const savedAgentMem = (await approvedMemSave.json()) as { id: string; title: string };
      assert.equal(savedAgentMem.title, 'Step 07 Verification Outcome');

      // 9. History endpoint lists audit entries
      const histRes = await fetch(`${baseUrl}/api/agent-history?task_id=${planned.task.id}`);
      assert.equal(histRes.status, 200);
      const histItems = (await histRes.json()) as Array<{ event_type: string }>;
      assert.ok(histItems.some((h) => h.event_type === 'memory_saved'));

      // 10. Rejection halts consequential execution cleanly & cancellation works
      const rejTaskRes = await fetch(`${baseUrl}/api/agent-tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          agent_id: agent.id,
          goal: 'Evaluate expression',
          code_snippet: '2 + 2',
          auto_run: true,
        }),
      });
      assert.equal(rejTaskRes.status, 201);
      const rejDetail = (await rejTaskRes.json()) as {
        task: { id: string; status: string };
        steps: Array<{ id: string; status: string }>;
      };
      assert.equal(rejDetail.task.status, 'awaiting_approval');
      const awaitingStep = rejDetail.steps.find((s) => s.status === 'awaiting_approval')!;
      const rejectedRes = await fetch(
        `${baseUrl}/api/agent-tasks/${rejDetail.task.id}/steps/${awaitingStep.id}/approve`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ approved: false, note: 'Declined by test' }),
        }
      );
      assert.equal(rejectedRes.status, 200);
      const afterReject = (await rejectedRes.json()) as { task: { status: string } };
      assert.equal(afterReject.task.status, 'failed');

      const cancelPlanRes = await fetch(`${baseUrl}/api/agent-tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ agent_id: agent.id, goal: 'Summarize workspace status', auto_run: false }),
      });
      const cancelPlanned = (await cancelPlanRes.json()) as { task: { id: string } };
      const cancelRes = await fetch(`${baseUrl}/api/agent-tasks/${cancelPlanned.task.id}/cancel`, { method: 'POST' });
      assert.equal(cancelRes.status, 200);
      assert.equal(((await cancelRes.json()) as { task: { status: string } }).task.status, 'cancelled');

      assert.equal(
        (await fetch(`${baseUrl}/api/agent-tasks/${cancelPlanned.task.id}`, { method: 'DELETE' })).status,
        200
      );

      // Clean up test memory & KB records
      await fetch(`${baseUrl}/api/memory/${savedAgentMem.id}`, { method: 'DELETE' });
      await fetch(`${baseUrl}/api/memory/${mem.id}`, { method: 'DELETE' });
      await fetch(`${baseUrl}/api/knowledge/${kb.id}`, { method: 'DELETE' });
    } finally {
      if (fs.existsSync(createdDocDiskPath)) {
        fs.unlinkSync(createdDocDiskPath);
      }
    }

    // 11. Unit checks for tool sandbox guards & safe retry logic using isolated workspace
    const sandboxTmp = fs.mkdtempSync(path.join(os.tmpdir(), 'genesis-agent-sandbox-'));
    try {
      const registry = new AgentToolRegistry();
      const db = getDb();
      const allowedAll = registry.getOperationalToolIds();
      const ctx = { db, agentId: agent.id, taskId: 'task-unit', workspaceRoot: sandboxTmp };

      // Block traversal, .db, .env
      const trav = await registry.invoke('read_workspace_file', { path: '../../package.json' }, allowedAll, ctx);
      assert.equal(trav.ok, false);
      const dbBlock = await registry.invoke('read_workspace_file', { path: 'genesis.db' }, allowedAll, ctx);
      assert.equal(dbBlock.ok, false);
      const envBlock = await registry.invoke('read_workspace_file', { path: '.env' }, allowedAll, ctx);
      assert.equal(envBlock.ok, false);

      // Block require/process/fs/eval in restricted VM
      const requireBlock = await registry.invoke(
        'run_restricted_code',
        { code: 'require("fs").readFileSync("/etc/passwd")' },
        allowedAll,
        ctx
      );
      assert.equal(requireBlock.ok, false);
      const evalBlock = await registry.invoke(
        'run_restricted_code',
        { code: 'eval("1 + 1")' },
        allowedAll,
        ctx
      );
      assert.equal(evalBlock.ok, false);

      // Allowlist enforcement & reserved stub refusal
      const notAllowed = await registry.invoke('read_workspace_file', { path: 'workspace_readme.txt' }, ['health_check'], ctx);
      assert.equal(notAllowed.ok, false);
      const futureStub = await registry.invoke('web_search_future', { query: 'test' }, ['web_search_future'], ctx);
      assert.equal(futureStub.ok, false);

      // Safe retry execution engine check
      let flakyCalls = 0;
      registry.register({
        id: 'test_retryable_tool',
        name: 'Test Retryable Tool',
        category: 'local_app',
        description: 'Fails once transiently then succeeds.',
        risk_level: 'read_only',
        requires_approval: false,
        safe_retryable: true,
        operational: true,
        input_schema: { type: 'object', properties: {} },
        execute: () => {
          flakyCalls += 1;
          if (flakyCalls === 1) {
            return { ok: false, summary: 'Transient glitch', data: {}, error: 'Temporary busy', retryable: true };
          }
          return { ok: true, summary: 'Recovered on retry', data: { attempts: flakyCalls } };
        },
      });
      const stateMgr = new TaskStateManager();
      const executor = new TaskExecutionEngine(registry, stateMgr, new AgentResultReporter());
      const retryTask = stateMgr.createTask(db, {
        agentId: agent.id,
        title: 'Retry Test',
        goal: 'Verify safe retry',
        planSteps: [
          {
            step_index: 0,
            title: 'Flaky Safe Op',
            description: 'Retries once',
            tool_name: 'test_retryable_tool',
            tool_input: {},
            requires_approval: false,
            safe_retryable: true,
          },
        ],
        memoryContext: { memories: [], knowledge: [] },
        maxRetries: 2,
      });
      const retryDone = await executor.executeTask(db, retryTask.task.id, { workspaceRoot: sandboxTmp });
      assert.equal(retryDone.task.status, 'completed');
      assert.equal(retryDone.steps[0].attempts, 2);
      const retryHist = stateMgr.listHistory(db, { taskId: retryTask.task.id });
      assert.ok(retryHist.some((h) => h.event_type === 'step_retried'));
    } finally {
      fs.rmSync(sandboxTmp, { recursive: true, force: true });
    }

    // 12. Chat settings (active_model_id, chat_use_memory, chat_use_knowledge) persist cleanly in Settings
    const updChatSettings = await fetch(`${baseUrl}/api/settings`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        active_model_id: 'local-inference-http',
        chat_use_memory: false,
        chat_use_knowledge: true,
      }),
    });
    assert.equal(updChatSettings.status, 200);
    const savedChatSettings = (await updChatSettings.json()) as {
      active_model_id: string;
      chat_use_memory: boolean;
      chat_use_knowledge: boolean;
    };
    assert.equal(savedChatSettings.active_model_id, 'local-inference-http');
    assert.equal(savedChatSettings.chat_use_memory, false);
    assert.equal(savedChatSettings.chat_use_knowledge, true);
  });
});



